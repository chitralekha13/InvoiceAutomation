from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
from werkzeug.utils import secure_filename
import json
from datetime import datetime, timedelta
import requests
import re
import uuid
import csv
import time
from dotenv import load_dotenv

# Azure Document Intelligence / Form Recognizer: use REST API (no SDK, works on Python 3.13+)
FORM_RECOGNIZER_AVAILABLE = True  # We use REST; no SDK import needed

# Directory (before loading .env so we know where to look)
backend_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(backend_dir)
frontend_dir = os.path.join(project_root, 'Frontend')

# Load .env from project root so AZURE_DI_* and IGENTIC_ENDPOINT are set
load_dotenv(os.path.join(project_root, '.env'))

app = Flask(__name__, static_folder=frontend_dir, static_url_path='')
CORS(app)

# Configuration
upload_folder = os.path.join(backend_dir, 'invoice uploads')
output_files = os.path.join(backend_dir, 'output.json')
fc_figures_store_file = os.path.join(backend_dir, 'fc_figures_store.json')
extn_allow = {'pdf', 'png', 'jpg', 'jpeg', 'PNG', 'JPG', 'JPEG'}

# Azure Document Intelligence (Form Recognizer) credentials for invoice extraction
# Set via environment: AZURE_DI_ENDPOINT, AZURE_DI_KEY
# Create a Document Intelligence resource in Azure Portal: https://portal.azure.com -> Create a resource -> search "Document Intelligence"
az_di_endpoint = os.getenv("AZURE_DI_ENDPOINT", os.getenv("AZURE_CV_ENDPOINT", "")).strip()
az_di_key = os.getenv("AZURE_DI_KEY", os.getenv("AZURE_CV_KEY", "")).strip()

# Agent Orchestration API (low-code platform / iGentic)
# Set via environment variable IGENTIC_ENDPOINT (recommended)
igentic_endpoint = os.getenv(
    "IGENTIC_ENDPOINT",
    "https://bluecoast-sk-eqe8f4e7e8gyfyds.eastus2-01.azurewebsites.net/api/iGenticAutonomousAgent/Executor/45d4a92e-168e-448a-97ee-567da3e0174e",
)

#Create Upload Folder
os.makedirs(upload_folder, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in extn_allow

def _analyze_invoice_rest(file_path):
    """
    Call Document Intelligence / Form Recognizer REST API to analyze an invoice.
    Uses prebuilt-invoice model; returns our invoice_data dict or None on failure.
    Tries both formrecognizer and documentintelligence paths for compatibility.
    """
    if not az_di_endpoint or not az_di_key:
        return None
    endpoint = az_di_endpoint.rstrip("/")
    # Try Form Recognizer path first, then Document Intelligence path
    candidates = [
        ("formrecognizer", "2023-07-31"),
        ("documentintelligence", "2023-07-31"),
        ("documentintelligence", "2024-11-30"),
    ]
    try:
        with open(file_path, "rb") as f:
            body = f.read()
    except Exception as e:
        print(f"Document Intelligence: could not read file: {e}")
        return None
    content_type = "application/octet-stream"
    if file_path.lower().endswith(".pdf"):
        content_type = "application/pdf"
    elif file_path.lower().endswith((".png", ".jpg", ".jpeg")):
        content_type = "image/jpeg" if "jpg" in file_path.lower() or "jpeg" in file_path.lower() else "image/png"
    headers = {"Ocp-Apim-Subscription-Key": az_di_key, "Content-Type": content_type}
    for path_prefix, api_version in candidates:
        analyze_url = f"{endpoint}/{path_prefix}/documentModels/prebuilt-invoice:analyze?api-version={api_version}"
        try:
            resp = requests.post(analyze_url, headers=headers, data=body, timeout=60)
            if resp.status_code in (404, 400, 401):
                continue
            if resp.status_code not in (200, 202):
                print(f"Document Intelligence analyze failed: {resp.status_code} {resp.text[:500]}")
                continue
            operation_location = resp.headers.get("Operation-Location")
            if not operation_location:
                continue
            # Poll for result (max 60 seconds)
            for _ in range(60):
                time.sleep(1)
                poll_headers = {"Ocp-Apim-Subscription-Key": az_di_key}
                poll_resp = requests.get(operation_location, headers=poll_headers, timeout=30)
                if poll_resp.status_code != 200:
                    continue
                result = poll_resp.json()
                status = result.get("status")
                if status == "succeeded":
                    # GET result often wraps payload in "analyzeResult"
                    payload = result.get("analyzeResult") or result.get("result") or result
                    return _invoice_data_from_rest_result(file_path, payload)
                if status == "failed":
                    print(f"Document Intelligence analysis failed: {result.get('error', {})}")
                    break
        except Exception as e:
            print(f"Document Intelligence REST error ({path_prefix}): {e}")
            continue
    return None


def _invoice_data_from_rest_result(file_path, result):
    """Build our standard invoice_data from REST API JSON result."""
    extracted_text = []
    all_lines = []
    pages = []
    full_text_parts = []
    raw_pages = result.get("pages") or []
    for page in raw_pages:
        page_number = page.get("pageNumber", len(pages) + 1)
        page_width = page.get("width") or 0
        page_height = page.get("height") or 0
        page_lines = []
        for line in page.get("lines") or []:
            text = (line.get("content") or "").strip()
            extracted_text.append(text)
            full_text_parts.append(text)
            line_info = {"text": text, "confidence": 1.0}
            if line.get("polygon"):
                line_info["bounding_box"] = line["polygon"]
            all_lines.append(line_info)
            page_lines.append(line_info)
        pages.append({
            "page_number": page_number,
            "width": page_width,
            "height": page_height,
            "lines": page_lines,
        })
    full_text = "\n".join(full_text_parts) if full_text_parts else ""
    # Fallback: some APIs return top-level "content" with full document text
    if not full_text and result.get("content"):
        full_text = result.get("content") or ""
        extracted_text = [s.strip() for s in full_text.split("\n") if s.strip()]
        all_lines = [{"text": t, "confidence": 1.0} for t in extracted_text]
    invoice_data = {
        "timestamp": datetime.now().isoformat(),
        "file_path": file_path,
        "extracted_text": extracted_text,
        "full_text": full_text,
        "status": "success",
        "all_lines": all_lines,
        "pages": pages,
        "source": "document_intelligence_rest",
    }
    # Prebuilt-invoice fields from result.documents
    docs = result.get("documents") or []
    if docs:
        fields = docs[0].get("fields") or {}
        di_parsed = _parsed_from_rest_invoice_fields(fields)
        if di_parsed:
            invoice_data["structured_extraction"] = di_parsed
    return invoice_data


def _rest_field_value(field):
    """Get value from REST API field object (valueString, valueNumber, valueDate, valueCurrency, valueObject, etc.)."""
    if not field or not isinstance(field, dict):
        return None
    for key in ("valueString", "valueNumber", "valueDate", "valueTime", "valuePhoneNumber", "valueCountryRegion"):
        if key in field and field[key] is not None:
            return field[key]
    # InvoiceTotal and amounts are often valueCurrency: { amount: number, currencySymbol: "USD" }
    if "valueCurrency" in field and field["valueCurrency"] is not None:
        curr = field["valueCurrency"]
        if isinstance(curr, dict) and "amount" in curr and curr["amount"] is not None:
            return curr["amount"]
        return curr
    if "valueObject" in field and field["valueObject"] is not None:
        return field["valueObject"]
    if "content" in field and field["content"] is not None:
        return field["content"]
    return None


def _parsed_from_rest_invoice_fields(fields):
    """Map REST API invoice fields to our canonical parser output."""
    out = {}
    for name, key in [
        ("InvoiceId", "invoice_number"),
        ("VendorName", "consultancy_name"),
        ("CustomerName", "customer_name"),
    ]:
        f = fields.get(name)
        v = _rest_field_value(f)
        if v is not None:
            out[key] = str(v).strip()
    f = fields.get("InvoiceTotal")
    if f is not None:
        v = _rest_field_value(f)
        if v is not None:
            try:
                out["invoice_amount"] = float(v)
            except (TypeError, ValueError):
                pass
    for name, key in [("InvoiceDate", "invoice_date"), ("DueDate", "due_date"), ("PaymentDueDate", "due_date")]:
        if key in out and key == "due_date" and name != "DueDate":
            continue
        f = fields.get(name)
        v = _rest_field_value(f)
        if v is not None:
            out[key] = _normalize_date_str(str(v))
    items = fields.get("Items")
    if items is not None:
        val = items.get("valueArray") or items.get("value") or []
        if isinstance(val, list):
            for it in val:
                obj = it if isinstance(it, dict) else (it.get("valueObject") or it.get("value") or {})
                if not isinstance(obj, dict):
                    continue
                qty = obj.get("Quantity") or obj.get("quantity")
                qv = _rest_field_value(qty) if isinstance(qty, dict) else qty
                if qv is not None:
                    try:
                        out["vendor_hours"] = out.get("vendor_hours", 0) + float(qv)
                    except (TypeError, ValueError):
                        pass
                amt = obj.get("Amount") or obj.get("amount")
                if amt is not None and "invoice_amount" not in out:
                    av = _rest_field_value(amt) if isinstance(amt, dict) else amt
                    if av is not None:
                        try:
                            out["invoice_amount"] = float(av)
                        except (TypeError, ValueError):
                            pass
    return out if out else None

def _pdf_to_text_fallback(file_path):
    """
    Fallback: extract text from PDF using PyMuPDF when Document Intelligence is not configured.
    Returns same structure as invoice_proc_az (extracted_text, full_text) or None.
    """
    try:
        import fitz  # PyMuPDF
        doc = fitz.open(file_path)
        lines = []
        for page in doc:
            for block in page.get_text("blocks"):
                if block[4].strip():
                    for line in block[4].strip().split("\n"):
                        if line.strip():
                            lines.append(line.strip())
        doc.close()
        if not lines:
            return None
        return {
            "timestamp": datetime.now().isoformat(),
            "file_path": file_path,
            "extracted_text": lines,
            "full_text": "\n".join(lines),
            "status": "success",
            "source": "pymupdf_fallback",
        }
    except ImportError:
        return None
    except Exception as e:
        print(f"PyMuPDF fallback error: {e}")
        return None


def invoice_proc_az(file_path):
    """
    Process invoice using Azure Document Intelligence / Form Recognizer (REST API) prebuilt-invoice model,
    or PyMuPDF fallback when DI is not configured.
    Uses REST only so it works on Python 3.13+ without the SDK.
    """
    try:
        if az_di_endpoint and az_di_key and FORM_RECOGNIZER_AVAILABLE:
            result = _analyze_invoice_rest(file_path)
            if result is not None:
                return result
        # DI not configured or REST failed: try PDF fallback (PDF only)
        ext = (file_path or "").lower()
        if ext.endswith(".pdf"):
            fallback = _pdf_to_text_fallback(file_path)
            if fallback:
                return fallback
        return None
    except Exception as e:
        return {
            "timestamp": datetime.now().isoformat(),
            "file_path": file_path,
            "status": "error",
            "error": str(e),
        }


def _normalize_date_str(date_str):
    """Normalize date string to YYYY-MM-DD; accepts MM/DD/YYYY, DD-MM-YYYY, month names, etc."""
    if not date_str or not isinstance(date_str, str):
        return date_str
    date_str = date_str.strip()
    try:
        from dateutil import parser as dateutil_parser
        parsed = dateutil_parser.parse(date_str)
        return parsed.strftime("%Y-%m-%d")
    except ImportError:
        pass
    except Exception:
        pass
    # Fallback: try common formats (no extra dependency)
    s = date_str[:20].strip()
    # Try month name format: "December 20, 2025" or "Dec 20, 2025"
    month_formats = [
        "%B %d, %Y",  # December 20, 2025
        "%b %d, %Y",  # Dec 20, 2025
        "%B %d %Y",   # December 20 2025
        "%b %d %Y",   # Dec 20 2025
    ]
    for fmt in month_formats:
        try:
            parsed = datetime.strptime(s, fmt)
            return parsed.strftime("%Y-%m-%d")
        except Exception:
            continue
    # Try numeric formats
    for fmt in ("%m/%d/%Y", "%m/%d/%y", "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%m-%d-%Y"):
        try:
            parsed = datetime.strptime(s[:10], fmt)
            # Handle 2-digit year (assume 2000s)
            if fmt.endswith("%y") and parsed.year < 2000:
                parsed = parsed.replace(year=parsed.year + 100)
            return parsed.strftime("%Y-%m-%d")
        except Exception:
            continue
    return date_str


def _month_name_to_dates(month_name, year):
    """Convert month name + year to start and end dates. Returns (start_date, end_date) or None."""
    month_map = {
        "january": 1, "jan": 1, "february": 2, "feb": 2, "march": 3, "mar": 3,
        "april": 4, "apr": 4, "may": 5, "june": 6, "jun": 6, "july": 7, "jul": 7,
        "august": 8, "aug": 8, "september": 9, "sep": 9, "october": 10, "oct": 10,
        "november": 11, "nov": 11, "december": 12, "dec": 12,
    }
    month_lower = month_name.lower().strip()
    if month_lower not in month_map:
        return None
    month_num = month_map[month_lower]
    try:
        year_int = int(year)
        # Get last day of month
        if month_num == 12:
            last_day = 31
        elif month_num in (4, 6, 9, 11):
            last_day = 30
        elif month_num == 2:
            last_day = 29 if (year_int % 4 == 0 and year_int % 100 != 0) or (year_int % 400 == 0) else 28
        else:
            last_day = 31
        start_date = f"{year_int}-{month_num:02d}-01"
        end_date = f"{year_int}-{month_num:02d}-{last_day:02d}"
        return (start_date, end_date)
    except Exception:
        return None


def _parse_invoice_from_ocr(invoice_data):
    """
    DEPRECATED: This function is no longer used.
    All field extraction is now done by iGentic agents (Invoice_Parser_Agent).
    This function is kept for reference but should not be called.
    
    Previously: Lightweight intelligent parsing from OCR result to improve accuracy.
    Extracts header fields (invoice number, dates, terms), vendor/customer, and totals
    using regex and layout. Result was merged into payload sent to orchestrator.
    """
    if not invoice_data or invoice_data.get("status") != "success":
        return {}
    full_text = invoice_data.get("full_text") or ""
    all_lines = invoice_data.get("all_lines") or [{"text": t} for t in invoice_data.get("extracted_text", [])]
    pages = invoice_data.get("pages") or []
    
    out = {}
    
    # Invoice number (optimized patterns)
    for pat in [
        r"Invoice\s*(?:No|Number|#|no)\.?\s*:?\s*([A-Z0-9-]+)",
        r"Invoice\s*#?\s*:?\s*([0-9]+)",
        r"Inv\.?\s*#?\s*:?\s*([A-Z0-9-]+)",
        r"#\s*([0-9]{3,})",  # Standalone number, at least 3 digits
    ]:
        m = re.search(pat, full_text, re.IGNORECASE)
        if m:
            out["invoice_number"] = m.group(1).strip()
            break
    
    # Invoice date (extract FIRST - needed for pay period and due date calculations)
    for pat in [
        r"Invoice\s*[Dd]ate\s*:?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})",
        r"Invoice\s*Date\s*:?\s*(\w+\s+\d{1,2},?\s+\d{4})",  # "December 20, 2025"
        r"Date\s*:?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})",
        r"(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})",  # Standalone date near top (first 500 chars)
    ]:
        search_text = full_text[:500] if pat == r"(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})" else full_text
        m = re.search(pat, search_text, re.IGNORECASE)
        if m:
            out["invoice_date"] = _normalize_date_str(m.group(1))
            break
    
    # Due date
    for pat in [
        r"Due\s*[Dd]ate\s*:?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})",
        r"Payment\s*Due\s*:?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})",
        r"Due\s*:?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})",
    ]:
        m = re.search(pat, full_text, re.IGNORECASE)
        if m:
            out["due_date"] = _normalize_date_str(m.group(1))
            break
    
    # Terms (Net 30, etc.)
    for pat in [
        r"Terms?\s*:?\s*(Net\s*\d+)",
        r"Payment\s*Terms?\s*:?\s*(Net\s*\d+)",
        r"(Net\s*\d+)",  # Standalone
    ]:
        m = re.search(pat, full_text, re.IGNORECASE)
        if m:
            out["net_terms"] = m.group(1).strip()
            break
    
    # Calculate due_date fallback: invoice_date + net_terms days
    if "due_date" not in out and out.get("invoice_date") and out.get("net_terms"):
        try:
            net_match = re.search(r"Net\s*(\d+)", out["net_terms"], re.IGNORECASE)
            if net_match:
                days = int(net_match.group(1))
                inv_date = datetime.strptime(out["invoice_date"], "%Y-%m-%d")
                due_date = inv_date + timedelta(days=days)
                out["due_date"] = due_date.strftime("%Y-%m-%d")
        except Exception:
            pass
    
    # Pay period: Try date range first, then month/year format, then separate start/end, then fallback
    # Pattern 1: Date range "Pay Period 12/01/2025 - 12/31/2025"
    m = re.search(r"(?:Pay\s*Period|Billing\s*Period|Period)\s*:?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})\s*[-–to]+\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})", full_text, re.IGNORECASE)
    if m:
        out["pay_period_start"] = _normalize_date_str(m.group(1))
        out["pay_period_end"] = _normalize_date_str(m.group(2))
    # Pattern 2: Month/Year format "NOVEMBER 2025" or "Nov 2025"
    if "pay_period_start" not in out:
        month_year_pat = r"(?:Pay\s*Period|Billing\s*Period|Period\s*for|Service\s*Period)\s*:?\s*(\w+)\s+(\d{4})"
        m = re.search(month_year_pat, full_text, re.IGNORECASE)
        if not m:
            # Standalone month/year: "NOVEMBER 2025" or "Nov 2025"
            m = re.search(r"(NOVEMBER|DECEMBER|JANUARY|FEBRUARY|MARCH|APRIL|MAY|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER)\s+(\d{4})", full_text, re.IGNORECASE)
        if not m:
            m = re.search(r"(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\.?\s+(\d{4})", full_text, re.IGNORECASE)
        if m:
            dates = _month_name_to_dates(m.group(1), m.group(2))
            if dates:
                out["pay_period_start"], out["pay_period_end"] = dates
    # Pattern 3: Separate Start/End dates
    if "pay_period_start" not in out:
        m = re.search(r"Start\s*[Dd]ate\s*:?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})", full_text, re.IGNORECASE)
        if m:
            out["pay_period_start"] = _normalize_date_str(m.group(1))
    if "pay_period_end" not in out:
        m = re.search(r"End\s*[Dd]ate\s*:?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})", full_text, re.IGNORECASE)
        if m:
            out["pay_period_end"] = _normalize_date_str(m.group(1))
    # Fallback: Use invoice_date's previous month
    if "pay_period_start" not in out and out.get("invoice_date"):
        try:
            inv_date = datetime.strptime(out["invoice_date"], "%Y-%m-%d")
            # Get first day of previous month
            if inv_date.month == 1:
                prev_month = 12
                prev_year = inv_date.year - 1
            else:
                prev_month = inv_date.month - 1
                prev_year = inv_date.year
            # Get last day of previous month
            if prev_month == 12:
                last_day = 31
            elif prev_month in (4, 6, 9, 11):
                last_day = 30
            elif prev_month == 2:
                last_day = 29 if (prev_year % 4 == 0 and prev_year % 100 != 0) or (prev_year % 400 == 0) else 28
            else:
                last_day = 31
            out["pay_period_start"] = f"{prev_year}-{prev_month:02d}-01"
            out["pay_period_end"] = f"{prev_year}-{prev_month:02d}-{last_day:02d}"
        except Exception:
            pass
    
    # Consultancy name (vendor): first lines that look like company (Inc, LLC, Solutions, etc.)
    for line_info in all_lines[:20]:
        text = (line_info.get("text") or "").strip()
        if not text or text.upper() in ("INVOICE", "BILL TO", "SHIP TO", "DATE"):
            continue
        # Skip lines that are only numbers
        if re.match(r"^[\d\s\-\$]+$", text):
            continue
        # Match company patterns
        if any(s in text for s in ("Inc", "LLC", "Ltd", "Corp", "Corporation", "Solutions", "Systems", "Consulting", "Technologies", "Services", "Group")):
            out["consultancy_name"] = text
            break
        # Fallback: First line that's all caps and 3+ words
        if text.isupper() and len(text.split()) >= 3:
            out["consultancy_name"] = text
            break
    
    # Resource name (customer/consultant): Look for human name patterns
    # Strategy 1: After "Bill to" or "Ship to"
    for i, line_info in enumerate(all_lines):
        t = (line_info.get("text") or "").lower()
        if "bill to" in t or "ship to" in t:
            for j in range(i + 1, min(i + 5, len(all_lines))):
                cand = (all_lines[j].get("text") or "").strip()
                if cand and cand.upper() not in ("BILL TO", "SHIP TO") and not re.match(r"^\d", cand):
                    if "customer_name" not in out and "resource_name" not in out:
                        out["resource_name"] = cand
                    break
            break
    # Strategy 2: Look for human name patterns in Description/Service section
    if "resource_name" not in out:
        for line_info in all_lines:
            text = (line_info.get("text") or "").strip()
            # Match "First Last" or "First - Last" patterns
            name_match = re.search(r"([A-Z][a-z]+\s+[A-Z][a-z]+)", text)
            if not name_match:
                name_match = re.search(r"([A-Z][a-z]+\s*[-–]\s*[A-Z][a-z]+)", text)
            if name_match and any(kw in text.lower() for kw in ("consultant", "designer", "developer", "engineer", "description", "service")):
                out["resource_name"] = name_match.group(1).strip()
                break
    # Fallback: If consultancy_name not found, use resource_name
    if "consultancy_name" not in out and out.get("resource_name"):
        out["consultancy_name"] = out["resource_name"]
    
    # Invoice amount (Total): Prefer "Total" label over other amounts
    for pat in [
        r"Total\s*:?\s*\$?\s*([\d,]+\.?\d{2})",
        r"Amount\s*Due\s*:?\s*\$?\s*([\d,]+\.?\d{2})",
        r"Invoice\s*Total\s*:?\s*\$?\s*([\d,]+\.?\d{2})",
        r"Grand\s*Total\s*:?\s*\$?\s*([\d,]+\.?\d{2})",
    ]:
        m = re.search(pat, full_text, re.IGNORECASE)
        if m:
            try:
                out["invoice_amount"] = float(m.group(1).replace(",", ""))
                break
            except Exception:
                pass
    # Fallback: Last $ amount or line containing "Total" / "Amount"
    if "invoice_amount" not in out:
        amounts = re.findall(r"\$([\d,]+\.?\d{2})", full_text)
        if amounts:
            try:
                last_amount = float(amounts[-1].replace(",", ""))
                out["invoice_amount"] = last_amount
            except Exception:
                pass
        if "invoice_amount" not in out:
            for line_info in all_lines:
                text = (line_info.get("text") or "").lower()
                if "total" in text or "amount due" in text:
                    am = re.search(r"\$([\d,]+\.?\d{2})", line_info.get("text", ""))
                    if am:
                        try:
                            out["invoice_amount"] = float(am.group(1).replace(",", ""))
                            break
                        except Exception:
                            pass
    
    # Validate and recalculate: invoice_amount should equal vendor_hours × pay_rate
    if out.get("vendor_hours") and out.get("pay_rate") and out.get("invoice_amount"):
        try:
            expected_amount = out["vendor_hours"] * out["pay_rate"]
            actual_amount = out["invoice_amount"]
            # If difference > $1, prefer calculated amount
            if abs(expected_amount - actual_amount) > 1.0:
                out["invoice_amount"] = round(expected_amount, 2)
        except Exception:
            pass
    # If amount exists but rate missing, calculate rate
    elif out.get("vendor_hours") and out.get("invoice_amount") and "pay_rate" not in out:
        try:
            out["pay_rate"] = round(out["invoice_amount"] / out["vendor_hours"], 2)
        except Exception:
            pass
    
    # Vendor hours: Look for "hours", "Qty", "Quantity" labels
    # Prefer reasonable hour values (>= 8 hours) unless explicitly labeled
    for pat in [
        r"(?:Hours|Qty|Quantity)\s*:?\s*(\d+(?:\.\d+)?)",
        r"(\d+(?:\.\d+)?)\s*(?:hours?|hrs?)",
    ]:
        m = re.search(pat, full_text, re.IGNORECASE)
        if m:
            try:
                hours = float(m.group(1))
                # Validation: max 243 hours, prefer >= 8 hours (full day) unless explicitly labeled
                # Only accept single digits if the pattern explicitly says "Hours:" or "Qty:"
                if pat.startswith(r"(?:Hours|Qty|Quantity)"):
                    # Explicit label - accept any reasonable value
                    if 1 <= hours <= 243:
                        out["vendor_hours"] = hours
                        break
                else:
                    # Implicit pattern (number followed by "hours") - prefer >= 8
                    if 8 <= hours <= 243:
                        out["vendor_hours"] = hours
                        break
            except Exception:
                pass
    
    # Line items: quantity and rate from table (Description, Qty, Rate, Amount)
    # Look for table structure with headers first, then extract from data rows
    if "vendor_hours" not in out:
        # Strategy 1: Find table header row (Qty, Quantity, Hours)
        header_idx = None
        for i, line_info in enumerate(all_lines):
            text = (line_info.get("text") or "").lower()
            if any(keyword in text for keyword in ["qty", "quantity", "hours", "hrs"]):
                header_idx = i
                break
        
        # Strategy 2: Extract from lines that look like line items (have both quantity and amount)
        # Prefer numbers that are reasonable for hours (>= 8, or clearly labeled)
        for i, line_info in enumerate(all_lines):
            text = (line_info.get("text") or "").strip()
            if len(text) < 3:
                continue
            
            # Skip header rows
            if header_idx is not None and i == header_idx:
                continue
            
            # Look for quantity patterns: "144 hours", "Qty: 144", or standalone reasonable numbers
            qty_match = None
            # Pattern 1: Explicit hours label
            qty_pat1 = re.search(r"(\d+(?:\.\d+)?)\s*(?:hours?|hrs?)", text, re.IGNORECASE)
            if qty_pat1:
                qty_match = qty_pat1
            # Pattern 2: Qty/Quantity label
            qty_pat2 = re.search(r"(?:Qty|Quantity)\s*:?\s*(\d+(?:\.\d+)?)", text, re.IGNORECASE)
            if qty_pat2:
                qty_match = qty_pat2
            # Pattern 3: Number followed by dollar amount (likely quantity in table row)
            nums = re.findall(r"\b(\d+(?:\.\d+)?)\b", text)
            ams = re.findall(r"\$([\d,]+\.?\d{2})", text)  # Dollar amounts with cents
            
            if qty_match:
                # Explicit hours/qty label found
                try:
                    qty = float(qty_match.group(1))
                    if 8 <= qty <= 243:  # Reasonable hours range
                        if ams:
                            am_clean = ams[-1].replace(",", "")
                            amount = float(am_clean)
                            if amount > 0:
                                out["vendor_hours"] = qty
                                if "invoice_amount" not in out:
                                    out["invoice_amount"] = amount
                                if "pay_rate" not in out:
                                    try:
                                        rate = amount / qty
                                        out["pay_rate"] = round(rate, 2)
                                    except Exception:
                                        pass
                                break
                except Exception:
                    pass
            elif nums and ams and len(nums) >= 2:
                # Table row with multiple numbers - prefer larger number as quantity
                # Filter out single digits and dates
                valid_nums = []
                for n in nums:
                    try:
                        num_val = float(n)
                        # Skip single digits (likely not hours) unless it's the only number
                        if num_val >= 8 or (num_val >= 1 and len(nums) == 1):
                            valid_nums.append((num_val, n))
                    except Exception:
                        pass
                
                if valid_nums:
                    # Use the largest number that's reasonable for hours
                    valid_nums.sort(reverse=True)
                    for num_val, num_str in valid_nums:
                        if 8 <= num_val <= 243:  # Reasonable hours range
                            try:
                                am_clean = ams[-1].replace(",", "")
                                amount = float(am_clean)
                                if amount > 0:
                                    out["vendor_hours"] = num_val
                                    if "invoice_amount" not in out:
                                        out["invoice_amount"] = amount
                                    if "pay_rate" not in out:
                                        try:
                                            rate = amount / num_val
                                            out["pay_rate"] = round(rate, 2)
                                        except Exception:
                                            pass
                                    break
                            except Exception:
                                pass
                    if "vendor_hours" in out:
                        break
    
    # Pay rate (Hourly rate): "Rate $89", "Hourly Rate: 89", "$/hr 89"
    if "pay_rate" not in out:
        for pat in [
            r"(?:Hourly\s*)?[Rr]ate\s*:?\s*\$?\s*([\d,]+\.?\d*)",
            r"(?:Rate|Per\s*Hour|/hr|/hour)\s*:?\s*\$?\s*([\d,]+\.?\d*)",
            r"\$([\d,]+\.?\d*)\s*(?:per\s*hour|/hr|/hour)",
        ]:
            m = re.search(pat, full_text, re.IGNORECASE)
            if m:
                try:
                    rate = float(m.group(1).replace(",", ""))
                    # Validate: if invoice_amount and vendor_hours exist, check if rate makes sense
                    if out.get("invoice_amount") and out.get("vendor_hours"):
                        expected_rate = out["invoice_amount"] / out["vendor_hours"]
                        # If extracted rate differs by >20%, prefer calculated rate
                        if abs(rate - expected_rate) / expected_rate > 0.2:
                            out["pay_rate"] = round(expected_rate, 2)
                        else:
                            out["pay_rate"] = rate
                    else:
                        out["pay_rate"] = rate
                    break
                except Exception:
                    pass
    
    # Business Unit: Look for exact matches (DEX, DATA, SIMS, ILD, RPA, CAI)
    bu_patterns = [
        r"BU\s*:?\s*(DEX|DATA|SIMS|ILD|RPA|CAI)",
        r"Business\s*Unit\s*:?\s*(DEX|DATA|SIMS|ILD|RPA|CAI)",
        r"\b(DEX|DATA|SIMS|ILD|RPA|CAI)\b",  # Standalone if clearly labeled
    ]
    for pat in bu_patterns:
        m = re.search(pat, full_text, re.IGNORECASE)
        if m:
            out["business_unit"] = m.group(1).upper()
            break
    
    # Project Name: Look in Description/Service section
    for pat in [
        r"Project\s*:?\s*(.+?)(?:\n|$)",
        r"Project\s*Name\s*:?\s*(.+?)(?:\n|$)",
        r"Description\s*:?\s*(.+?)(?:\n|$)",
        r"Service\s*:?\s*(.+?)(?:\n|$)",
    ]:
        m = re.search(pat, full_text, re.IGNORECASE | re.MULTILINE)
        if m:
            project = m.group(1).strip()
            # Limit to 100 chars
            if len(project) > 100:
                project = project[:100]
            out["project_name"] = project
            break
    
    # Average confidence from OCR lines
    confs = [line_info.get("confidence", 1.0) for line_info in all_lines if isinstance(line_info, dict)]
    if confs:
        out["_ocr_avg_confidence"] = round(sum(confs) / len(confs), 4)
    
    return out


def _build_canonical_invoice_structure(parsed_from_ocr, doc_name=None):
    """
    DEPRECATED: This function is no longer used.
    All field extraction and structuring is now done by iGentic agents.
    This function is kept for reference but should not be called.
    
    Previously: Built a single canonical JSON structure for the invoice using FC Figures field names.
    Used as the main payload to the orchestrator and to populate the dashboard row.
    Orchestrator could further organize or override these fields.
    """
    if not parsed_from_ocr or not isinstance(parsed_from_ocr, dict):
        return {}
    # Map parser output to exact dashboard/orchestrator field names; drop internal keys
    canonical = {}
    field_map = {
        "invoice_number": "invoice_number",
        "invoice_no": "invoice_number",
        "consultancy_name": "consultancy_name",
        "vendor_name": "consultancy_name",
        "resource_name": "resource_name",
        "customer_name": "resource_name",  # fallback when resource name not present
        "pay_period_start": "pay_period_start",
        "start_date": "pay_period_start",
        "pay_period_end": "pay_period_end",
        "end_date": "pay_period_end",
        "net_terms": "net_terms",
        "payment_terms": "net_terms",
        "vendor_hours": "vendor_hours",
        "invoice_hours": "vendor_hours",
        "hours": "vendor_hours",
        "pay_rate": "pay_rate",
        "hourly_rate": "pay_rate",
        "invoice_amount": "invoice_amount",
        "total_amount": "invoice_amount",
        "amount": "invoice_amount",
        "invoice_date": "invoice_date",
        "due_date": "due_date",
        "invoice_received_date": "invoice_received_date",
    }
    for src_key, dst_key in field_map.items():
        val = parsed_from_ocr.get(src_key)
        if val is not None and val != "":
            if dst_key not in canonical:
                canonical[dst_key] = val
    if doc_name:
        canonical["doc_name"] = doc_name
    return canonical


#JSON data sent to Igentic Orchestrator
def igentic_json_post(invoice_data):
    """Send invoice data to agent orchestration API"""
    try:
        full_url = igentic_endpoint
        if not full_url:
            return {
                "status": "error",
                "error": "IGENTIC_ENDPOINT is not configured",
                "error_type": "missing_configuration"
            }
        headers = {
            "Content-Type": "application/json" 
        }
        
        payload = {
            "request": "Process invoice",
            "userInput":json.dumps(invoice_data),
            "sessionId": ""
        }
        
        # Make API call to agent orchestration
        print(f"Calling API")
        
        response = requests.post(
            full_url,
            json=payload,
            headers=headers,
            timeout=30
        )

        #print(f"Response: {response.json()}")
        response.raise_for_status()
        return response.json()
        
    except requests.exceptions.RequestException as e:
        print(f"Error calling agent orchestration API: {str(e)}")
        if hasattr(e, 'response') and e.response is not None:
            print(f"Response status: {e.response.status_code}")
            print(f"Response text: {e.response.text}")
        return {
            "status": "error",
            "error": str(e),
            "error_type": "api_request_failed"
        }

    except Exception as e:
        print(f"Unexpected error in agent orchestration: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_type": "unexpected_error"
        }

def _safe_get(dct, *keys, default=None):
    cur = dct
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur

def _now_iso():
    return datetime.now().isoformat()

def _read_json_file(path, default):
    try:
        if not os.path.exists(path):
            return default
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if data is not None else default
    except Exception:
        return default

def _write_json_file(path, data):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception:
        return False

def _read_fc_store():
    data = _read_json_file(fc_figures_store_file, {"rows": []})
    if not isinstance(data, dict) or "rows" not in data or not isinstance(data["rows"], list):
        return {"rows": []}
    return data

def _write_fc_store(store):
    return _write_json_file(fc_figures_store_file, store)

def _find_row_by_session_or_invoice(rows, session_id=None, invoice_number=None):
    for r in rows:
        if not isinstance(r, dict):
            continue
        if session_id and r.get("sessionId") == session_id:
            return r
        if invoice_number and r.get("invoice_number") == invoice_number:
            return r
    return None

def _extract_json_block(text):
    """
    Try to extract a JSON object embedded in markdown (```json ...```) or plain JSON.
    Returns a dict if found, else None.
    """
    if not isinstance(text, str):
        return None
    
    # Try markdown code block first (```json ...```)
    m = re.search(r"```json\s*([\s\S]*?)\s*```", text, re.IGNORECASE)
    if m:
        blob = m.group(1).strip()
        print(f"DEBUG _extract_json_block: Found JSON code block, length: {len(blob)}")
        try:
            val = json.loads(blob)
            if isinstance(val, dict):
                print(f"DEBUG _extract_json_block: Successfully parsed JSON, keys: {list(val.keys())}")
                return val
            else:
                print(f"DEBUG _extract_json_block: Parsed value is not a dict: {type(val)}")
        except json.JSONDecodeError as e:
            print(f"DEBUG _extract_json_block: JSON decode error: {e}")
            print(f"DEBUG _extract_json_block: Blob preview: {blob[:200]}...")
        except Exception as e:
            print(f"DEBUG _extract_json_block: Unexpected error: {e}")
    
    # Try to find JSON object directly in text (look for { ... } pattern)
    # Use a more robust pattern that handles nested objects
    json_match = re.search(r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}', text)
    if json_match:
        try:
            val = json.loads(json_match.group(0))
            if isinstance(val, dict):
                print(f"DEBUG _extract_json_block: Found JSON object directly, keys: {list(val.keys())}")
                return val
        except Exception as e:
            print(f"DEBUG _extract_json_block: Failed to parse JSON object: {e}")
    
    print(f"DEBUG _extract_json_block: No JSON found in text (length: {len(text)})")
    return None

def _extract_csv_block(text):
    """
    Extract CSV data from orchestrator responses (generic, no hard-coded field names).
    Returns a dict with normalized keys based on CSV headers, or None.
    """
    if not isinstance(text, str):
        return None
    
    # Look for CSV blocks in various formats:
    # 1. ```csv ...``` (explicit CSV block)
    # 2. ``` ...``` with CSV content (triple backticks without csv label)
    # 3. Plain CSV lines (header + data row)
    
    csv_text = None
    
    # Pattern 1: Explicit ```csv block
    csv_match = re.search(r"```csv\s*([\s\S]*?)\s*```", text, re.IGNORECASE)
    if csv_match:
        csv_text = csv_match.group(1).strip()
        print(f"DEBUG _extract_csv_block: Found ```csv block, length: {len(csv_text)}")
    else:
        # Pattern 2: Triple backticks with CSV content (like "CSV-Style String")
        # Look for lines between ``` that contain CSV headers
        backtick_match = re.search(r"```\s*\n([\s\S]*?)\n```", text)
        if backtick_match:
            potential_csv = backtick_match.group(1).strip()
            # Check if it looks like CSV (has commas and Invoice/Vendor headers)
            if ',' in potential_csv and ('Invoice' in potential_csv or 'Vendor' in potential_csv):
                csv_text = potential_csv
                print(f"DEBUG _extract_csv_block: Found CSV in ``` block (no csv label), length: {len(csv_text)}")
        
        # Pattern 3: Plain CSV lines (fallback)
        # Only look for CSV if it's NOT JSON (avoid parsing JSON as CSV)
        if not csv_text:
            lines = text.split('\n')
            csv_lines = []
            for line in lines:
                line_stripped = line.strip()
                # Skip lines that look like JSON (have colons and quotes in JSON format)
                # JSON format: "Invoice_Number": "1205" or { "Invoice_Number": "1205" }
                if ':' in line_stripped and '"' in line_stripped:
                    # Check if it's JSON format (key: value with quotes)
                    if re.search(r'"[^"]+"\s*:\s*', line_stripped):
                        continue  # Skip JSON lines
                # Detect CSV: has commas, contains Invoice/Vendor/Resource headers
                # CSV format: Invoice_Number,Vendor_Name,... (no colons, just commas)
                if ',' in line_stripped and ('Invoice' in line_stripped or 'Vendor' in line_stripped or 'Resource' in line_stripped):
                    # Make sure it's not JSON (no colons in CSV)
                    if ':' not in line_stripped:
                        csv_lines.append(line_stripped)
                        # Stop after header + data row
                        if len(csv_lines) >= 2:
                            break
            if csv_lines:
                csv_text = '\n'.join(csv_lines)
                print(f"DEBUG _extract_csv_block: Found CSV lines (plain text), {len(csv_lines)} lines")
            else:
                print(f"DEBUG _extract_csv_block: No CSV pattern detected")
    
    if not csv_text:
        return None
    
    try:
        lines = csv_text.strip().split('\n')
        if len(lines) < 2:
            return None
        
        # Parse header (CSV reader handles quoted fields automatically)
        reader = csv.reader([lines[0]], quotechar='"')
        headers = next(reader)
        headers = [h.strip().strip('"') for h in headers]  # Remove quotes if present
        
        # Parse first data row
        reader = csv.reader([lines[1]], quotechar='"')
        values = next(reader)
        values = [v.strip().strip('"') for v in values]  # Remove quotes if present
        
        print(f"DEBUG _extract_csv_block: Parsed {len(headers)} headers: {headers[:5]}...")
        print(f"DEBUG _extract_csv_block: Parsed {len(values)} values: {values[:5]}...")
        
        if len(headers) != len(values):
            return None
        
        # Build dict with normalized keys (lowercase, spaces->underscores)
        result = {}
        for h, v in zip(headers, values):
            if not v or v == '':
                continue
            # Normalize header to snake_case
            # Handle PascalCase with underscores: Invoice_Number -> invoice_number
            key = str(h).strip().strip('"')
            if '_' in key:
                key = key.lower()  # Invoice_Number -> invoice_number
            else:
                # Convert PascalCase to snake_case then lowercase
                key = re.sub(r'(?<!^)(?=[A-Z])', '_', key).lower()
            key = key.replace(' ', '_').replace('-', '_')
            
            print(f"DEBUG _extract_csv_block: Normalized header '{h}' -> '{key}'")
            
            # Map common variations (map the full normalized key, don't remove prefixes)
            key_mapping = {
                'invoice_number': 'invoice_number',
                'vendor_name': 'consultancy_name',
                'consultancy_name': 'consultancy_name',
                'resource_name': 'resource_name',
                'start_date': 'pay_period_start',
                'pay_period_start': 'pay_period_start',
                'end_date': 'pay_period_end',
                'pay_period_end': 'pay_period_end',
                'invoice_hours': 'vendor_hours',
                'vendor_hours': 'vendor_hours',
                'hours': 'vendor_hours',
                'hourly_rate': 'pay_rate',
                'pay_rate': 'pay_rate',
                'rate': 'pay_rate',
                'total_amount': 'invoice_amount',
                'invoice_amount': 'invoice_amount',
                'amount': 'invoice_amount',
                'payment_terms': 'net_terms',
                'net_terms': 'net_terms',
                'terms': 'net_terms',
                'invoice_date': 'invoice_date',
                'due_date': 'due_date',
                'business_unit': 'business_unit',
                'bu': 'business_unit',
                'project_name': 'project_name',
                'project': 'project_name',
                'template': 'template',
            }
            final_key = key_mapping.get(key, key)
            print(f"DEBUG _extract_csv_block: Mapped '{key}' -> '{final_key}', value: '{v}'")
            
            # Coerce numeric fields
            if final_key in ('vendor_hours', 'pay_rate', 'invoice_amount', 'approved_hours'):
                try:
                    v_clean = v.replace(',', '').replace('$', '').strip()
                    result[final_key] = float(v_clean) if v_clean else None
                except Exception:
                    result[final_key] = v
            else:
                result[final_key] = v
        
        return result if result else None
    except Exception as e:
        print(f"CSV extraction error: {e}")
        return None

def _extract_markdown_summary(text):
    """
    Extract structured data from markdown summary format like:
    - **Invoice Number:** 1205
    - **Vendor Name:** Keen Technology Solutions LLC
    - **Resource Name:** Rajendra Charry
    Returns a dict with extracted fields, or None if no summary found.
    """
    if not isinstance(text, str):
        return None
    
    # Look for "Invoice Summary:" or similar headers, or just bullet points with **Field Name:**
    # Also handle "Extracted Information:" format
    has_summary_format = (
        re.search(r'(?:Invoice\s+Summary|Summary|Invoice\s+Details|Extracted\s+Information)[:\s]*\n', text, re.IGNORECASE | re.MULTILINE) or
        re.search(r'[-•]\s*\*\*[^*]+\*\*:\s*', text) or
        re.search(r'\*\*[^*]+\*\*:\s*', text)
    )
    
    if not has_summary_format:
        print(f"DEBUG _extract_markdown_summary: No summary format detected")
        return None
    
    print(f"DEBUG _extract_markdown_summary: Summary format detected, extracting...")
    result = {}
    
    # Pattern to match: - **Field Name:** value
    # Also handles: **Field Name:** value (without bullet)
    # Match until next bullet, newline with **, or end of text
    # Use simpler pattern that matches line by line
    pattern = r'[-•]?\s*\*\*([^*]+)\*\*:\s*(.+?)(?=\n|$)'
    matches = re.findall(pattern, text, re.MULTILINE | re.IGNORECASE)
    
    print(f"DEBUG _extract_markdown_summary: Found {len(matches)} matches")
    
    for field_name, value in matches:
        field_name_orig = field_name
        field_name = field_name.strip().lower().replace(' ', '_').replace('-', '_')
        value = value.strip()
        
        # Clean up value (remove markdown, extra spaces, newlines)
        value = re.sub(r'\*\*', '', value)  # Remove bold markers
        value = re.sub(r'\s+', ' ', value)  # Normalize whitespace
        value = value.strip()
        
        # Skip empty values or placeholders
        if not value or value.lower() in ('null', 'none', 'n/a', '-', ''):
            print(f"DEBUG: Skipping empty field: {field_name_orig} = '{value}'")
            continue
        
        # Map field names to canonical format
        # Handle both "Invoice Number" (spaces) and "Invoice_Number" (underscores)
        field_mapping = {
            'invoice_number': 'invoice_number',
            'invoice_no': 'invoice_number',
            'vendor_name': 'consultancy_name',
            'consultancy_name': 'consultancy_name',
            'resource_name': 'resource_name',
            'invoice_hours': 'vendor_hours',
            'hours': 'vendor_hours',
            'vendor_hours': 'vendor_hours',
            'hourly_rate': 'pay_rate',
            'rate': 'pay_rate',
            'pay_rate': 'pay_rate',
            'total_amount': 'invoice_amount',
            'amount': 'invoice_amount',
            'invoice_amount': 'invoice_amount',
            'invoice_date': 'invoice_date',
            'payment_terms': 'net_terms',
            'net_terms': 'net_terms',
            'terms': 'net_terms',
            'due_date': 'due_date',
            'start_date': 'pay_period_start',
            'pay_period_start': 'pay_period_start',
            'end_date': 'pay_period_end',
            'pay_period_end': 'pay_period_end',
            'business_unit': 'business_unit',
            'bu': 'business_unit',
            'project_name': 'project_name',
            'project': 'project_name',
        }
        
        mapped_key = field_mapping.get(field_name, field_name)
        
        # Convert numeric values
        if mapped_key in ('vendor_hours', 'pay_rate', 'invoice_amount', 'approved_hours'):
            try:
                # Remove $ and commas
                clean_value = value.replace('$', '').replace(',', '').strip()
                result[mapped_key] = float(clean_value)
                print(f"DEBUG: Extracted numeric {mapped_key} = {result[mapped_key]} from '{value}'")
            except (ValueError, AttributeError) as e:
                result[mapped_key] = value
                print(f"DEBUG: Could not convert {mapped_key} to float: {e}, keeping as string: '{value}'")
        else:
            result[mapped_key] = value
            print(f"DEBUG: Extracted {mapped_key} = '{value}'")
    
    print(f"DEBUG _extract_markdown_summary: Final result: {list(result.keys()) if result else 'None'}")
    return result if result else None

def _extract_structured_from_orchestrator(orchestration_response, display_text, user_input_str=None):
    """
    Extract structured data from orchestrator responses ONLY.
    
    CRITICAL: This function extracts data ONLY from the orchestrator response.
    NO HARD-CODED VALUES - all data comes from iGentic platform responses.
    
    Priority order (all sources are from orchestrator - NO LOCAL PARSING):
    1. Structured fields already in orchestration_response (fc_figures_row, parsed_data, etc.)
    2. CSV blocks from orchestrator (e.g., Excel_Formatter_Agent output)
    3. JSON blocks in markdown (```json ...```) from orchestrator
    4. Agent responses array from orchestrator
    5. User input JSON (only if it contains orchestrator-provided parsed_data)
    
    Returns a dict with FC Figures-like fields, or None if orchestrator provides no structured data.
    The orchestrator's CSV/JSON structure drives column mapping, not hard-coded field names.
    
    IMPORTANT: If this returns None, it means the orchestrator did not provide structured data.
    The code will NOT create fake/hardcoded values - empty fields remain empty until orchestrator provides them.
    """
    parsed = None
    
    def _has_usable_values(d):
        """Treat empty dict or dict with only null/empty values as no data so we fall through to Priority 5."""
        if not isinstance(d, dict) or not d:
            print(f"DEBUG _has_usable_values: Not a dict or empty: {type(d)}")
            return False
        usable_count = 0
        for k, v in d.items():
            if v is not None and v != "":
                usable_count += 1
        print(f"DEBUG _has_usable_values: Found {usable_count} usable values out of {len(d)} total fields")
        return usable_count > 0

    # Priority 1: Structured fields already in orchestration response (most reliable)
    if isinstance(orchestration_response, dict):
        parsed = (
            _safe_get(orchestration_response, "fc_figures_row")
            or _safe_get(orchestration_response, "parsed_data")
            or _safe_get(orchestration_response, "invoice_data")
            or _safe_get(orchestration_response, "excel_data", "structured_data")
            or _safe_get(orchestration_response, "output", "excel_data", "structured_data")
            or _safe_get(orchestration_response, "data", "parsed_data")
            or _safe_get(orchestration_response, "data", "invoice_data")
        )
        if not isinstance(parsed, dict) or not _has_usable_values(parsed):
            parsed = None
    
    # Priority 2: JSON blocks in markdown (iGentic often returns JSON in ```json blocks)
    # Try JSON FIRST since it's more structured and reliable
    if not parsed:
        if display_text:
            print(f"DEBUG Priority 2 (JSON): Attempting JSON block extraction from display_text (length: {len(display_text)})")
            parsed = _extract_json_block(display_text)
            if parsed:
                print(f"SUCCESS: Extracted JSON from markdown block: {list(parsed.keys())}, values: {[(k, v) for k, v in list(parsed.items())[:3]]}")
            else:
                print(f"DEBUG: JSON block extraction returned None")
        else:
            print(f"DEBUG Priority 2 (JSON): display_text is None or empty")
    if parsed is not None and not _has_usable_values(parsed):
        print(f"DEBUG: JSON block has no usable values (all null/empty): {parsed}")
        parsed = None
    
    # Priority 3: CSV blocks (orchestrator often returns CSV for Excel export)
    # Only try CSV if JSON extraction failed
    if not parsed:
        if display_text:
            print(f"DEBUG Priority 3 (CSV): Attempting CSV block extraction from display_text (length: {len(display_text)})")
            parsed = _extract_csv_block(display_text)
            if parsed:
                print(f"SUCCESS: Extracted CSV block: {list(parsed.keys())}, values: {[(k, v) for k, v in list(parsed.items())[:3]]}")
            else:
                print(f"DEBUG: CSV block extraction returned None")
        else:
            print(f"DEBUG Priority 3 (CSV): display_text is None or empty")
    if parsed is not None and not _has_usable_values(parsed):
        print(f"DEBUG: CSV block has no usable values (all null/empty): {parsed}")
        parsed = None
    
    # Priority 3b: Markdown summary format (e.g., "**Invoice Number:** 1205" or "**Invoice_Number:** 1205")
    # Fallback if JSON block extraction didn't work
    if not parsed:
        if display_text:
            print(f"DEBUG: Attempting markdown summary extraction. display_text length: {len(display_text)}, first 500 chars: {display_text[:500]}...")
            parsed = _extract_markdown_summary(display_text)
            if parsed:
                print(f"SUCCESS: Extracted from markdown summary: {list(parsed.keys())}")  # Debug
            else:
                print(f"DEBUG: Markdown summary extraction returned None")
        else:
            print(f"DEBUG: display_text is None or empty")
    if parsed is not None and not _has_usable_values(parsed):
        print(f"DEBUG: Parsed data has no usable values: {parsed}")
        parsed = None
    
    # Priority 4: Try to extract from agentResponses if it's a JSON string
    if not parsed and isinstance(orchestration_response, dict):
        agent_responses = orchestration_response.get("agentResponses")
        if isinstance(agent_responses, str):
            try:
                responses = json.loads(agent_responses)
                if isinstance(responses, list):
                    # Look for structured data in the last response
                    for resp in reversed(responses):
                        if isinstance(resp, dict):
                            content = resp.get("Content") or resp.get("content") or ""
                            if content:
                                # Try to extract JSON from content
                                json_data = _extract_json_block(content)
                                if json_data and _has_usable_values(json_data):
                                    parsed = json_data
                                    break
            except Exception:
                pass
    
    # Priority 5: User input JSON (only if it contains orchestrator-provided data)
    # NO LOCAL PARSING FALLBACK - all extraction must come from iGentic agents
    if not parsed and isinstance(user_input_str, str):
        try:
            ui = json.loads(user_input_str)
            if isinstance(ui, dict):
                # Only use parsed_data if it came from orchestrator (not local parsing)
                if isinstance(ui.get("parsed_data"), dict):
                    parsed = ui.get("parsed_data")
                # Don't use structured_extraction - that was local parsing, now removed
        except Exception:
            parsed = None
    
    # If we got structured data, normalize keys generically (preserve orchestrator's structure)
    if parsed and isinstance(parsed, dict):
        # Normalize common key variations without hard-coding field names
        normalized = {}
        for k, v in parsed.items():
            if v is None or v == '':
                continue
            # Normalize key to snake_case
            # Handle PascalCase (Invoice_Number) and convert to lowercase snake_case
            key = str(k).strip()
            # Convert PascalCase_With_Underscores to lowercase (e.g., Invoice_Number -> invoice_number)
            if '_' in key:
                key = key.lower()
            else:
                # Convert PascalCase to snake_case then lowercase (e.g., InvoiceNumber -> invoice_number)
                import re
                key = re.sub(r'(?<!^)(?=[A-Z])', '_', key).lower()
            key = key.replace(' ', '_').replace('-', '_')
            
            print(f"DEBUG: Normalized key '{k}' -> '{key}'")
            # Map common variations (but let orchestrator's structure drive it)
            # Field mapping based on Invoice_Parser_Agent FC Figures Canonical Data Model
            # Required Fields: ID, Resource Name, Current Comments, Joining Date, Ending Date, BU,
            # Project Name, Consultancy Name, Invoice No., Pay period, new net terms, Vendor hours,
            # Pay rate, Amount, Date Inv recd, Due Date, Template, Bill Pay initiated on,
            # Approval Status, Addl Comments
            key_mapping = {
                # Invoice identification (handle both snake_case and PascalCase)
                'invoice_number': 'invoice_number',
                'invoice_no': 'invoice_number',
                'invoice_num': 'invoice_number',
                # Vendor/Consultancy
                'vendor_name': 'consultancy_name',
                'vendor': 'consultancy_name',
                'consultancy_name': 'consultancy_name',
                'consultancy': 'consultancy_name',
                # Resource
                'resource_name': 'resource_name',
                'resource': 'resource_name',
                # Pay period dates (Invoice_Parser_Agent extracts from "month of December" → Start/End dates)
                'start_date': 'pay_period_start',
                'pay_period_start': 'pay_period_start',
                'pay_period': 'pay_period_start',  # Partial match
                'end_date': 'pay_period_end',
                'pay_period_end': 'pay_period_end',
                # Hours and rate
                'invoice_hours': 'vendor_hours',
                'vendor_hours': 'vendor_hours',
                'hours': 'vendor_hours',
                'hourly_rate': 'pay_rate',
                'pay_rate': 'pay_rate',
                'rate': 'pay_rate',
                # Amount (Invoice_Parser_Agent calculates if missing: Hours × Rate)
                'total_amount': 'invoice_amount',
                'invoice_amount': 'invoice_amount',
                'amount': 'invoice_amount',
                # Payment terms
                'payment_terms': 'net_terms',
                'net_terms': 'net_terms',
                'new_net_terms': 'net_terms',  # From FC Figures model
                'terms': 'net_terms',
                # Dates
                'invoice_date': 'invoice_date',
                'due_date': 'due_date',
                'date_inv_recd': 'invoice_received_date',  # Date Inv recd - MM/DD/YEAR
                'invoice_received_date': 'invoice_received_date',
                # Business unit and project
                'business_unit': 'business_unit',
                'bu': 'business_unit',
                'project_name': 'project_name',
                'project': 'project_name',
                # Template (Vendor/C2C/employee)
                'template': 'template',
                # Joining/Ending dates
                'joining_date': 'joining_date',
                'ending_date': 'ending_date',
                # Comments
                'current_comments': 'current_comments',
                'addl_comments': 'addl_comments',
                'additional_comments': 'addl_comments',
                # Approval status
                'approval_status': 'approval_status',
                'status': 'approval_status',
                # Bill pay
                'bill_pay_initiated_on': 'bill_pay_initiated_on',
            }
            final_key = key_mapping.get(key, key)
            
            # Coerce numeric fields
            if final_key in ('vendor_hours', 'pay_rate', 'invoice_amount', 'approved_hours'):
                try:
                    if isinstance(v, (int, float)):
                        normalized[final_key] = float(v)
                    else:
                        v_clean = str(v).replace(',', '').replace('$', '').strip()
                        normalized[final_key] = float(v_clean) if v_clean else None
                except Exception:
                    normalized[final_key] = v
            else:
                normalized[final_key] = v
        
        return normalized if normalized else None
    
    return None

def _extract_payment_details(orchestration_response, display_text):
    """
    Extract payment details from Payment_Approval_Agent output.
    Payment_Approval_Agent provides payment information in JSON format when invoice is ready for payment.
    
    Returns: Dict with payment details (account numbers, routing, amounts, etc.) or None
    """
    payment_details = None
    
    # Priority 1: Check for payment_details in orchestration response
    if isinstance(orchestration_response, dict):
        payment_details = (
            _safe_get(orchestration_response, "payment_details")
            or _safe_get(orchestration_response, "payment_info")
            or _safe_get(orchestration_response, "payment_information")
            or _safe_get(orchestration_response, "fc_figures_row", "payment_details")
        )
        if payment_details and isinstance(payment_details, dict):
            return payment_details
    
    # Priority 2: Extract from display_text (Payment_Approval_Agent output)
    if display_text and isinstance(display_text, str):
        # Look for JSON block with payment details
        # Payment_Approval_Agent outputs: "Display payment summary and give payment details in JSON format"
        text_lower = display_text.lower()
        
        # Check if this is Payment_Approval_Agent output (has payment-related keywords)
        is_payment_agent_output = (
            "payment" in text_lower and ("details" in text_lower or "information" in text_lower or "summary" in text_lower)
        ) or "payment_approval_agent" in text_lower or "ready for payment" in text_lower
        
        if is_payment_agent_output:
            # Try to extract JSON block (most common format)
            json_data = _extract_json_block(display_text)
            if json_data and isinstance(json_data, dict):
                # Check if this JSON contains payment-related fields
                payment_keys = ["account_number", "routing_number", "bank_name", "payment_amount", 
                               "vendor_account", "payment_method", "payment_date", "transaction_id",
                               "account", "routing", "bank", "amount", "method", "date", "vendor",
                               "invoice_number", "invoice_amount", "pay_to", "pay_from"]
                json_str = str(json_data).lower()
                if any(key.lower() in json_str for key in payment_keys):
                    return json_data
                
                # If JSON has payment-related structure, return it
                if len(json_data) > 0:
                    # Check if keys suggest payment info
                    keys_lower = [k.lower() for k in json_data.keys()]
                    if any("payment" in k or "account" in k or "routing" in k or "bank" in k or "vendor" in k for k in keys_lower):
                        return json_data
            
            # Also try to parse JSON from plain text (if not in code block)
            # Look for JSON-like structure in the text
            try:
                # Find JSON object in text (between { and })
                import json as json_module
                start_idx = display_text.find('{')
                end_idx = display_text.rfind('}')
                if start_idx != -1 and end_idx != -1 and end_idx > start_idx:
                    json_str = display_text[start_idx:end_idx+1]
                    parsed = json_module.loads(json_str)
                    if isinstance(parsed, dict) and len(parsed) > 0:
                        # Check if it looks like payment details
                        keys_lower = [k.lower() for k in parsed.keys()]
                        if any("payment" in k or "account" in k or "routing" in k or "bank" in k or "vendor" in k for k in keys_lower):
                            return parsed
            except Exception:
                pass
    
    return None

def _extract_status_from_orchestrator(orchestration_response, display_text):
    """
    Extract approval status from orchestrator responses ONLY.
    
    Based on Invoice_Finance_Automation_OrchestratorV2 workflow:
    - Timesheet_Verification_Agent sets approval_status based on hours comparison:
      * Hours Match (timesheet == invoice) → "Complete" / "Workflow Status: Complete"
      * Timesheet > Invoice → "Need manual review" / "Manual check required"
      * Invoice > Timesheet → "NEED APPROVAL" / "Manual check required"
    
    NO HARD-CODED DEFAULTS - returns None if orchestrator doesn't provide status.
    """
    # Priority 1: Check for structured status in orchestration response
    if isinstance(orchestration_response, dict):
        status = (
            _safe_get(orchestration_response, "approval_status")
            or _safe_get(orchestration_response, "status")
            or _safe_get(orchestration_response, "workflow_state")
            or _safe_get(orchestration_response, "fc_figures_row", "approval_status")
        )
        if status:
            status_str = str(status).strip().lower()
            # Match Timesheet_Verification_Agent status values
            if "complete" in status_str:
                return "Complete"
            if "need approval" in status_str or "need_approval" in status_str:
                return "NEED APPROVAL"
            if "need manual review" in status_str or "manual review" in status_str:
                return "NEED APPROVAL"  # "Need manual review" → NEED APPROVAL
            if "pending" in status_str:
                return "Pending"
    
    # Priority 2: Extract from display text (orchestrator's agent output)
    if display_text and isinstance(display_text, str):
        t = display_text.lower()
        
        # Timesheet_Verification_Agent outputs:
        # - "Workflow Status: Complete" when hours match
        # - "Manual check required" when hours mismatch
        # - "approval_status": "Complete" / "NEED APPROVAL" / "Need manual review"
        
        # Check for "Workflow Status: Complete" pattern (Timesheet_Verification_Agent output)
        if "workflow status" in t and "complete" in t:
            return "Complete"
        
        # Check for hours mismatch indicators (Timesheet_Verification_Agent logic)
        if "manual check required" in t or "manual check" in t:
            return "NEED APPROVAL"  # Manual check required = needs approval
        if "hours mismatch" in t or "hour mismatch" in t:
            return "NEED APPROVAL"  # Hours mismatch = needs approval
        if "timesheet hours is more" in t or "timesheet exceeds" in t:
            return "NEED APPROVAL"  # Timesheet > Invoice = needs approval
        if "invoice exceeds" in t or "invoice > timesheet" in t:
            return "NEED APPROVAL"  # Invoice > Timesheet = needs approval
        
        # Check for complete/ready status (including Payment_Approval_Agent output)
        if "ready for payment" in t or "workflow complete" in t or "payment ready" in t:
            return "Complete"
        if "ready for payment processing" in t or "payment approval" in t:
            return "Complete"
        if "complete" in t and ("workflow" in t or "status" in t or "ready" in t):
            return "Complete"
        # Payment_Approval_Agent marks invoice as "Ready for Payment"
        if "ready for payment" in t and ("payment_approval_agent" in t or "payment details" in t):
            return "Complete"
        
        # Check for approval needed
        if "need approval" in t or "need_approval" in t:
            return "NEED APPROVAL"
        if "need manual review" in t or "manual review" in t:
            return "NEED APPROVAL"
    
    # Return None if orchestrator doesn't provide status (don't default to Pending)
    return None

def _upsert_fc_row(session_id, orchestration_response, user_input_str=None, pre_structured=None, event_type=None):
    """
    Create/Update a FC-Figures-like row. Uses ONLY iGentic orchestrator responses.
    All field extraction is done by iGentic agents - no local parsing.
    """
    store = _read_fc_store()
    rows = store["rows"]

    workflow = _extract_workflow_output(orchestration_response)
    display_text = workflow.get("display_text")
    
    # Extract fields ONLY from orchestrator response (no local parsing)
    print(f"DEBUG _upsert_fc_row: display_text type={type(display_text)}, length={len(display_text) if display_text else 0}")
    if display_text:
        print(f"DEBUG _upsert_fc_row: display_text preview (first 1000 chars): {display_text[:1000]}...")
        # Also check if JSON block is visible
        if "```json" in display_text:
            print(f"DEBUG _upsert_fc_row: Found ```json block in display_text")
        if '"Invoice_Number"' in display_text or '"Invoice_Number"' in display_text:
            print(f"DEBUG _upsert_fc_row: Found Invoice_Number in display_text")
    else:
        print(f"DEBUG _upsert_fc_row: display_text is None or empty!")
        # Fallback: try to get display_text directly from orchestration_response
        if isinstance(orchestration_response, dict):
            result_val = orchestration_response.get("result")
            if isinstance(result_val, str):
                print(f"DEBUG _upsert_fc_row: Using result field directly as display_text fallback")
                display_text = result_val
    
    fields = _extract_structured_from_orchestrator(orchestration_response, display_text, user_input_str) or {}
    if not fields:
        print(f"WARNING: No fields extracted from orchestrator. display_text length: {len(display_text) if display_text else 0}")
        print(f"Orchestration response keys: {list(orchestration_response.keys()) if isinstance(orchestration_response, dict) else 'not a dict'}")
        if isinstance(orchestration_response, dict) and "result" in orchestration_response:
            result_val = orchestration_response.get("result")
            print(f"DEBUG: result field type={type(result_val)}, length={len(str(result_val)) if result_val else 0}")
            if isinstance(result_val, str):
                print(f"DEBUG: result preview: {result_val[:500]}...")
    else:
        print(f"SUCCESS: Extracted {len(fields)} fields from orchestrator: {list(fields.keys())}")
    invoice_number = fields.get("invoice_number")
    
    # Also extract approved_hours from orchestrator if present (e.g., from Timesheet_Verification_Agent)
    if isinstance(orchestration_response, dict):
        approved_hours = (
            _safe_get(orchestration_response, "approved_hours")
            or _safe_get(orchestration_response, "timesheet_hours")
            or _safe_get(orchestration_response, "fc_figures_row", "approved_hours")
        )
        if approved_hours is not None:
            try:
                fields["approved_hours"] = float(approved_hours)
            except Exception:
                pass
    
    # Extract bill_pay_initiated_on if orchestrator provides it
    if isinstance(orchestration_response, dict):
        bill_pay = (
            _safe_get(orchestration_response, "bill_pay_initiated_on")
            or _safe_get(orchestration_response, "fc_figures_row", "bill_pay_initiated_on")
        )
        if bill_pay:
            fields["bill_pay_initiated_on"] = bill_pay
    
    # Extract payment details from Payment_Approval_Agent (when status is Complete)
    payment_details = _extract_payment_details(orchestration_response, display_text)
    if payment_details:
        fields["payment_details"] = payment_details
        print(f"DEBUG: Extracted payment details: {list(payment_details.keys()) if isinstance(payment_details, dict) else 'non-dict'}")

    # Allow duplicate uploads: Only create new row for "upload" event type
    # For other event types (workflow_continue, workflow_next_participant, etc.), update existing row if found
    if event_type == "upload":
        # Upload event: Always create a new row (allow duplicate uploads for comparison)
        row = None
    else:
        # Non-upload events: Try to find existing row first (by session_id or invoice_number)
        row = _find_row_by_session_or_invoice(rows, session_id=session_id, invoice_number=invoice_number)
    
    # Create new row only if not found (for upload) or if no existing row (for other events)
    if row is None:
        row = {
            "invoice_uuid": str(uuid.uuid4()),
            "created_at": _now_iso(),
            "sessionId": session_id,
            # Manual-entry fields
            "current_comments": "",
            "joining_date": None,
            "ending_date": None,
            "template": None,
            "addl_comments": "",
            "approved_hours": None,
            "bill_pay_initiated_on": None,
            "payment_details": None,  # Payment details from Payment_Approval_Agent
            "doc_name": None,  # Document name from upload
            # Auto fields - ONLY set from orchestrator, no hardcoded defaults
            "approval_status": None,  # Will be set by orchestrator only
            "invoice_received_date": _now_iso(),
        }
        rows.append(row)

    # Auto fields overwrite when present (from orchestrator only)
    # IMPORTANT: Save all extracted fields to the row
    print(f"DEBUG: Saving {len(fields)} fields to row: {list(fields.keys())}")
    for k, v in fields.items():
        if v is not None and v != '':
            row[k] = v
            print(f"DEBUG: Set row['{k}'] = {v} (type: {type(v).__name__})")
        else:
            print(f"DEBUG: Skipping empty field: {k} = {v}")
    
    print(f"DEBUG: Row after saving fields: invoice_number={row.get('invoice_number')}, vendor_hours={row.get('vendor_hours')}, invoice_amount={row.get('invoice_amount')}")

    row["last_event_type"] = event_type
    row["last_updated_at"] = _now_iso()

    # Extract status from orchestrator ONLY - preserve existing status if orchestrator doesn't provide new one
    derived_status = _extract_status_from_orchestrator(orchestration_response, display_text)
    if derived_status:
        # Orchestrator provided status - update it
        row["approval_status"] = derived_status
    # If orchestrator doesn't provide status, keep existing status (retain memory)
    # Only set default if this is a brand new row with no status
    if row.get("approval_status") is None:
        # New row, but orchestrator didn't provide status - set to Pending as initial state
        # This is the ONLY place we set a default, and only for new rows
        row["approval_status"] = "Pending"
    
    # Note: Fields may be empty if orchestrator doesn't provide them - that's expected
    # All extraction is done by iGentic agents, so empty fields mean agents didn't extract them

    # Ensure invoice_received_date is populated (only if missing)
    if not row.get("invoice_received_date"):
        row["invoice_received_date"] = row.get("created_at") or _now_iso()

    # Preserve agent output for "details" panel
    row["last_agent_text"] = display_text
    row["last_agent_name"] = workflow.get("next_participant")

    _write_fc_store(store)
    return row

_KNOWN_PARTICIPANTS = {
    # Invoice_Finance_Automation_OrchestratorV2 agents (from agent_config.json)
    "Invoice_Parser_Agent",           # Extracts invoice fields, calculates missing amounts
    "Excel_Formatter_Agent",          # Formats data for Excel export, signals READY_FOR_EXCEL_WRITE
    "Timesheet_Verification_Agent",   # Validates hours, sets approval_status (Complete/Need manual review/NEED APPROVAL)
    "Summary_Status_Agent",           # Provides status summary, determines payment readiness
    "Payment_Approval_Agent",         # Marks invoice ready for payment processing
}

def _maybe_participant_name(value):
    """
    If the value looks like an exact participant name, return it; otherwise None.
    """
    if not isinstance(value, str):
        return None
    candidate = value.strip()
    return candidate if candidate in _KNOWN_PARTICIPANTS else None

def _extract_workflow_output(orchestration_response):
    """
    Normalize the low-code platform response into UI-friendly fields.
    We don't implement agent logic here; we only surface what the platform returns.
    """
    # Some low-code router agents return a plain string (e.g., "Timesheet_Verification_Agent")
    if isinstance(orchestration_response, str):
        return {
            "raw": orchestration_response,
            "next_participant": orchestration_response.strip() or None,
            "display_text": orchestration_response,
            "sessionId": None
        }

    if not isinstance(orchestration_response, dict):
        return {
            "raw": orchestration_response,
            "next_participant": None,
            "display_text": None,
            "sessionId": None
        }

    # Common fields we might get back from orchestration platforms
    session_id = (
        orchestration_response.get("sessionId")
        or orchestration_response.get("session_id")
        or _safe_get(orchestration_response, "data", "sessionId")
        or _safe_get(orchestration_response, "data", "session_id")
    )

    # "Return only participant name" selector agents may return plain text in a nested field
    next_participant = (
        orchestration_response.get("next_participant")
        or orchestration_response.get("next_agent")
        or _safe_get(orchestration_response, "result", "next_participant")
        or _safe_get(orchestration_response, "result", "next_agent")
        or _safe_get(orchestration_response, "output", "next_participant")
        or _safe_get(orchestration_response, "output", "next_agent")
    )

    # Display text for UI (whatever the low-code agent produced)
    # Check if result is a string (markdown) or dict first
    # iGentic often returns the agent output in the "result" field as a string
    result_value = orchestration_response.get("result")
    if isinstance(result_value, str):
        display_text = result_value  # result is markdown text containing JSON blocks
        print(f"DEBUG _extract_workflow_output: Using result field as display_text (length: {len(display_text)})")
    else:
        display_text = (
            orchestration_response.get("text")
            or orchestration_response.get("message")
            or _safe_get(orchestration_response, "result", "text")
            or _safe_get(orchestration_response, "result", "message")
            or _safe_get(orchestration_response, "output", "text")
            or _safe_get(orchestration_response, "output", "message")
        )
        if display_text:
            print(f"DEBUG _extract_workflow_output: Using alternative field for display_text (length: {len(display_text)})")
        else:
            print(f"DEBUG _extract_workflow_output: No display_text found in response")

    # Sometimes the agent returns a string directly in "output"
    if display_text is None and isinstance(orchestration_response.get("output"), str):
        display_text = orchestration_response.get("output")

    # Many iGentic executors return agentResponses as a JSON-string array.
    # We don't interpret logic; we just surface the latest agent's name/content for the UI.
    if (display_text is None or display_text == "(no text)") and isinstance(orchestration_response.get("agentResponses"), str):
        try:
            parsed = json.loads(orchestration_response.get("agentResponses"))
            if isinstance(parsed, list) and parsed:
                last = parsed[-1] if isinstance(parsed[-1], dict) else None
                if last:
                    content = last.get("Content") or last.get("content")
                    author = last.get("AuthorName") or last.get("author") or last.get("name")
                    if content:
                        display_text = content
                    if next_participant is None and author:
                        next_participant = author
        except Exception:
            pass

    # If we still don't have next_participant, and the agent returned just the name in "result",
    # infer it (but only if it matches the known participant list).
    if next_participant is None:
        next_participant = _maybe_participant_name(display_text)

    return {
        "raw": orchestration_response,
        "next_participant": next_participant,
        "display_text": display_text,
        "sessionId": session_id
    }

def local_json_backup(data):
    try:
        if os.path.exists(output_files):
            with open(output_files, 'r', encoding='utf-8') as f:
                try:
                    existing_data = json.load(f)
                    if not isinstance(existing_data, list):
                        existing_data = [existing_data]
                except json.JSONDecodeError:
                    existing_data = []
        else:
            existing_data = []
        
        # Append new data
        existing_data.append(data)
        
        # Write back to file
        with open(output_files, 'w', encoding='utf-8') as f:
            json.dump(existing_data, f, indent=2, ensure_ascii=False)
        
        return True
		
    except Exception as e:
        print(f"Error saving to output.json: {str(e)}")
        return False

def _read_output_log():
    """
    Read Backend/output.json if present.
    Returns a list (may be empty).
    """
    try:
        if not os.path.exists(output_files):
            return []
        with open(output_files, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            return data
        if data is None:
            return []
        return [data]
    except Exception:
        return []

@app.route('/dashboard/recent', methods=['GET'])
def dashboard_recent():
    """
    Live dashboard data feed for the internal portal.
    Reads from output.json (the audit trail) and returns the most recent entries.
    """
    try:
        limit = request.args.get("limit", "25")
        try:
            limit = max(1, min(200, int(limit)))
        except Exception:
            limit = 25

        entries = _read_output_log()
        entries = list(reversed(entries))[:limit]

        # Light normalization for UI convenience
        normalized = []
        for e in entries:
            if not isinstance(e, dict):
                continue
            normalized.append({
                "timestamp": e.get("timestamp"),
                "type": e.get("type") or e.get("event") or "log",
                "sessionId": e.get("sessionId") or e.get("session_id"),
                "workflow": e.get("workflow"),
                "request": e.get("request"),
                # show only small previews in UI; raw stays available separately if needed
                "userInput_preview": (e.get("userInput")[:800] if isinstance(e.get("userInput"), str) else None),
            })

        return jsonify({
            "status": "ok",
            "count": len(normalized),
            "items": normalized
        }), 200
    except Exception as e:
        return jsonify({"status": "error", "details": str(e)}), 500

@app.route('/')
def index():
    """Serve the index.html file from Frontend"""
    return send_from_directory(frontend_dir, 'index.html')

@app.route('/dashboard')
def dashboard():
    """Serve the dashboard page"""
    return send_from_directory(frontend_dir, 'dashboard.html')

@app.route('/api/dashboard/data', methods=['GET'])
def api_dashboard_data():
    """
    Returns structured dashboard data (cards + table rows) derived from fc_figures_store.json.
    Query params:
      - status: filter by approval_status
      - due_date: YYYY-MM-DD filter (rows with due_date <= this date)
    """
    store = _read_fc_store()
    rows = store.get("rows", [])

    status = request.args.get("status")
    due_date = request.args.get("due_date")

    def _due_ok(r):
        if not due_date:
            return True
        rd = r.get("due_date")
        if not rd:
            return False
        try:
            # compare as strings for ISO dates
            return str(rd) <= str(due_date)
        except Exception:
            return True

    filtered = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        if status and str(r.get("approval_status")) != str(status):
            continue
        if not _due_ok(r):
            continue
        filtered.append(r)

    def _sum_amount(items):
        total = 0.0
        for r in items:
            try:
                v = r.get("invoice_amount")
                if isinstance(v, (int, float)):
                    total += float(v)
            except Exception:
                pass
        return round(total, 2)

    # Backward-compat mapping from older statuses (only for display, preserve orchestrator values)
    # Note: This is for legacy data only - new data comes from orchestrator only
    for r in filtered:
        if r.get("approval_status") == "To Start":
            r["approval_status"] = "Pending"
        if r.get("approval_status") == "In Progress":
            r["approval_status"] = "Pending"
        if r.get("approval_status") == "Need Approval":
            r["approval_status"] = "NEED APPROVAL"
        # Ensure status is never None (for display purposes only)
        if r.get("approval_status") is None:
            r["approval_status"] = "Pending"

    counts = {
        "total": len(filtered),
        "pending": sum(1 for r in filtered if r.get("approval_status") == "Pending"),
        "complete": sum(1 for r in filtered if r.get("approval_status") == "Complete"),
        "need_approval": sum(1 for r in filtered if r.get("approval_status") == "NEED APPROVAL"),
        "payment_initiated": sum(1 for r in filtered if r.get("bill_pay_initiated_on")),
        "total_amount": _sum_amount(filtered),
    }

    # Sort newest first
    def _sort_key(r):
        return r.get("last_updated_at") or r.get("created_at") or ""
    filtered_sorted = sorted(filtered, key=_sort_key, reverse=True)

    return jsonify({"status": "ok", "metrics": counts, "rows": filtered_sorted}), 200

@app.route('/api/fcfigures/<invoice_uuid>/update', methods=['POST'])
def api_fcfigures_update(invoice_uuid):
    """
    Update manual fields for a row (notes, BU, Project, Approved Hours, etc).
    If Approved Hours is provided and a sessionId exists, we also forward it to iGentic via /workflow/continue
    and then upsert the row based on the orchestration response (so status updates reflect the workflow).
    """
    store = _read_fc_store()
    rows = store.get("rows", [])
    row = None
    for r in rows:
        if isinstance(r, dict) and r.get("invoice_uuid") == invoice_uuid:
            row = r
            break
    if row is None:
        return jsonify({"error": "Invoice not found"}), 404

    body = request.get_json(silent=True) or {}
    editable_fields = [
        "current_comments",
        "joining_date",
        "ending_date",
        "business_unit",
        "project_name",
        "consultancy_name",
        "template",
        "addl_comments",
        "approved_hours",
    ]
    for f in editable_fields:
        if f in body:
            row[f] = body.get(f)

    row["last_updated_at"] = _now_iso()
    _write_fc_store(store)

    # If approved_hours updated and we have sessionId, trigger workflow continuation
    approved_hours = body.get("approved_hours", None)
    if approved_hours is not None and row.get("sessionId"):
        try:
            headers = {"Content-Type": "application/json"}
            # Send a structured payload so the orchestrator can validate hours and update status/notes.
            payload = {
                "request": "Timesheet_Verification_Agent (dashboard)",
                "userInput": json.dumps(
                    {
                        "approved_hours": approved_hours,
                        "invoice_number": row.get("invoice_number"),
                        "vendor_hours": row.get("vendor_hours"),
                        "resource_name": row.get("resource_name"),
                    },
                    ensure_ascii=False,
                ),
                "sessionId": row.get("sessionId"),
            }
            resp = requests.post(igentic_endpoint, json=payload, headers=headers, timeout=30)
            resp.raise_for_status()
            orchestration_response = resp.json()
            _upsert_fc_row(row.get("sessionId"), orchestration_response, user_input_str=None, event_type="dashboard_approved_hours")

            local_json_backup({
                "timestamp": _now_iso(),
                "type": "dashboard_approved_hours",
                "sessionId": row.get("sessionId"),
                "userInput": str(approved_hours),
                "agent_orchestration": orchestration_response,
                "workflow": _extract_workflow_output(orchestration_response),
            })
        except Exception:
            pass

    return jsonify({"status": "ok"}), 200

@app.route('/api/fcfigures/<invoice_uuid>/summary', methods=['POST'])
def api_fcfigures_summary(invoice_uuid):
    """
    Ask the orchestrator to generate a summary for the selected invoice (Summary_Status_Agent behavior).
    We store the returned text on the row for display in the dashboard.
    """
    store = _read_fc_store()
    rows = store.get("rows", [])
    row = None
    for r in rows:
        if isinstance(r, dict) and r.get("invoice_uuid") == invoice_uuid:
            row = r
            break
    if row is None:
        return jsonify({"error": "Invoice not found"}), 404
    if not row.get("sessionId"):
        return jsonify({"error": "This invoice has no sessionId yet (cannot ask orchestrator for summary)."}), 400

    try:
        headers = {"Content-Type": "application/json"}
        payload = {
            "request": "Summary_Status_Agent (dashboard)",
            "userInput": json.dumps(
                {
                    "invoice_number": row.get("invoice_number"),
                    "resource_name": row.get("resource_name"),
                    "vendor_hours": row.get("vendor_hours"),
                    "approved_hours": row.get("approved_hours"),
                    "approval_status": row.get("approval_status"),
                },
                ensure_ascii=False,
            ),
            "sessionId": row.get("sessionId"),
        }
        resp = requests.post(igentic_endpoint, json=payload, headers=headers, timeout=30)
        resp.raise_for_status()
        orchestration_response = resp.json()
        workflow = _extract_workflow_output(orchestration_response)
        
        # Get summary from orchestrator ONLY - no hardcoded fallbacks
        summary_text = workflow.get("display_text") or ""
        # Also check if orchestrator provides summary in structured format
        if not summary_text and isinstance(orchestration_response, dict):
            summary_text = (
                _safe_get(orchestration_response, "summary")
                or _safe_get(orchestration_response, "orchestrator_summary")
                or _safe_get(orchestration_response, "fc_figures_row", "orchestrator_summary")
            ) or ""

        # Persist summary exactly as orchestrator provides it (no interpretation)
        row["orchestrator_summary"] = summary_text
        row["last_updated_at"] = _now_iso()
        _write_fc_store(store)

        # Also keep audit
        local_json_backup({
            "timestamp": _now_iso(),
            "type": "dashboard_summary",
            "sessionId": row.get("sessionId"),
            "invoice_uuid": invoice_uuid,
            "agent_orchestration": orchestration_response,
            "workflow": workflow,
        })

        return jsonify({"status": "ok", "summary": summary_text, "workflow": workflow}), 200
    except requests.exceptions.RequestException as e:
        err_txt = str(e)
        if hasattr(e, "response") and e.response is not None:
            err_txt = f"{err_txt} | status={e.response.status_code} | body={e.response.text}"
        return jsonify({"error": "Orchestrator request failed", "details": err_txt}), 502
    except Exception as e:
        return jsonify({"error": "Server error", "details": str(e)}), 500

@app.route('/api/dashboard/export', methods=['GET'])
def api_dashboard_export():
    """
    Export selected invoices as CSV (Excel-compatible).
    Query param: ids=comma-separated invoice_uuid values
    """
    ids = request.args.get("ids", "")
    want = set([i.strip() for i in ids.split(",") if i.strip()]) if ids else set()

    store = _read_fc_store()
    rows = [r for r in store.get("rows", []) if isinstance(r, dict)]
    if want:
        rows = [r for r in rows if r.get("invoice_uuid") in want]

    headers = [
        "invoice_uuid",
        "doc_name",
        "invoice_number",
        "resource_name",
        "consultancy_name",
        "pay_period_start",
        "pay_period_end",
        "vendor_hours",
        "pay_rate",
        "invoice_amount",
        "net_terms",
        "invoice_date",
        "invoice_received_date",
        "due_date",
        "business_unit",
        "project_name",
        "approval_status",
        "approved_hours",
        "bill_pay_initiated_on",
        "current_comments",
        "addl_comments",
    ]

    def esc(v):
        if v is None:
            return ""
        s = str(v)
        s = s.replace('"', '""')
        return f"\"{s}\""

    lines = [",".join(headers)]
    for r in rows:
        lines.append(",".join(esc(r.get(h)) for h in headers))
    csv_data = "\n".join(lines)

    return (
        csv_data,
        200,
        {
            "Content-Type": "text/csv; charset=utf-8",
            "Content-Disposition": "attachment; filename=fc_figures_export.csv",
        },
    )

@app.route('/upload', methods=['POST'])
def upload_file():
    """Handle file upload and processing"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not allowed_file(file.filename):
            return jsonify({'error': 'Invalid file type. Allowed types: PDF, PNG, JPG, JPEG'}), 400
        
        # Save the file
        filename = secure_filename(file.filename)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename_with_timestamp = f"{timestamp}_{filename}"
        file_path = os.path.join(upload_folder, filename_with_timestamp)
        file.save(file_path)
        
        # Process with Azure Document Intelligence (Form Recognizer) or PDF fallback
        # This only extracts RAW TEXT - all field extraction is done by iGentic agents
        print(f"Processing invoice: {filename_with_timestamp}")
        invoice_data = invoice_proc_az(file_path)
        
        if not invoice_data:
            if not (az_di_endpoint and az_di_key):
                return jsonify({
                    'error': 'Azure Document Intelligence is not configured. Set AZURE_DI_ENDPOINT and AZURE_DI_KEY, or install PyMuPDF (pip install pymupdf) for PDF-only fallback.'
                }), 500
            return jsonify({'error': 'Failed to process invoice with Document Intelligence'}), 500
        
        # Payload to orchestrator: ONLY raw OCR text - let iGentic agents do all extraction
        # No local parsing - iGentic Invoice_Parser_Agent handles all field extraction
        payload_for_orchestrator = {
            "doc_name": filename_with_timestamp,
            "full_text": (invoice_data.get("full_text") or "")[:15000],
            "extracted_text": (invoice_data.get("extracted_text") or [])[:500],
            "timestamp": invoice_data.get("timestamp"),
            "status": invoice_data.get("status"),
        }
        
        print("Sending raw OCR text to iGentic orchestrator for extraction...")
        orchestration_response = igentic_json_post(payload_for_orchestrator)
        print(f"Orchestration response type: {type(orchestration_response)}")
        if isinstance(orchestration_response, dict):
            print(f"Orchestration response keys: {list(orchestration_response.keys())}")
            if "result" in orchestration_response:
                result_val = orchestration_response.get("result")
                print(f"Result field type: {type(result_val)}, length: {len(str(result_val)) if result_val else 0}")
                if isinstance(result_val, str):
                    print(f"Result preview (first 500 chars): {result_val[:500]}...")

        workflow = _extract_workflow_output(orchestration_response)
        display_text = workflow.get("display_text")
        print(f"Extracted display_text type: {type(display_text)}, length: {len(display_text) if display_text else 0}")
        if display_text:
            print(f"Display_text preview (first 500 chars): {display_text[:500]}...")
        session_id = workflow.get("sessionId") or ""
        
        # Populate dashboard ONLY from orchestrator response (no local extraction)
        print(f"Calling _upsert_fc_row with session_id={session_id}, event_type=upload")
        row = _upsert_fc_row(
            session_id,
            orchestration_response,
            user_input_str=None,
            pre_structured=None,
            event_type="upload",
        )
        print(f"Row created/updated: invoice_uuid={row.get('invoice_uuid') if row else None}")
        if row:
            print(f"Row fields: invoice_number={row.get('invoice_number')}, vendor_hours={row.get('vendor_hours')}, invoice_amount={row.get('invoice_amount')}")
        
        # Ensure doc_name is on the row
        if row and not row.get("doc_name"):
            row["doc_name"] = filename_with_timestamp
            store = _read_fc_store()
            for r in store.get("rows", []):
                if isinstance(r, dict) and r.get("invoice_uuid") == row.get("invoice_uuid"):
                    r["doc_name"] = filename_with_timestamp
                    break
            _write_fc_store(store)
        
        # Combine invoice data with orchestration response
        final_data = {
            "invoice_processing": invoice_data,
            "agent_orchestration": orchestration_response,
            "workflow": workflow,
            "uploaded_file": filename_with_timestamp
        }
        
        # Save to output.json
        if local_json_backup(final_data):
            print("Data saved to output.json")
        else:
            print("Warning: Failed to save data to output.json")
        
        return jsonify({
            'message': 'File uploaded and processed successfully',
            'filename': filename_with_timestamp,
            'data': final_data,
            'workflow': workflow,
            'invoice_uuid': row.get("invoice_uuid") if row else None
        }), 200
        
    except Exception as e:
        print(f"Error processing upload: {str(e)}")
        return jsonify({'error': f'Server error: {str(e)}'}), 500

@app.route('/workflow/continue', methods=['POST'])
def workflow_continue():
    """
    Generic continuation endpoint: frontend sends user input (e.g., approved hours / "approve")
    and a sessionId, and we forward it to the low-code agent platform.
    """
    try:
        if not igentic_endpoint:
            return jsonify({"error": "IGENTIC_ENDPOINT is not configured"}), 500

        body = request.get_json(silent=True) or {}
        user_input = body.get("userInput")
        session_id = body.get("sessionId") or ""
        request_type = body.get("request") or "Continue workflow"

        if user_input is None:
            return jsonify({"error": "Missing required field: userInput"}), 400

        headers = {"Content-Type": "application/json"}
        payload = {
            "request": request_type,
            "userInput": user_input,
            "sessionId": session_id
        }

        resp = requests.post(igentic_endpoint, json=payload, headers=headers, timeout=30)
        resp.raise_for_status()
        orchestration_response = resp.json()
        workflow = _extract_workflow_output(orchestration_response)

        # Save a small audit trail
        local_json_backup({
            "timestamp": datetime.now().isoformat(),
            "type": "workflow_continue",
            "request": request_type,
            "sessionId": session_id,
            "userInput": user_input,
            "agent_orchestration": orchestration_response,
            "workflow": workflow
        })

        # Update FC Figures store (structured dashboard)
        _upsert_fc_row(session_id, orchestration_response, user_input_str=str(user_input), event_type="workflow_continue")

        return jsonify({"workflow": workflow, "data": orchestration_response}), 200

    except requests.exceptions.RequestException as e:
        err_txt = str(e)
        if hasattr(e, "response") and e.response is not None:
            err_txt = f"{err_txt} | status={e.response.status_code} | body={e.response.text}"
        return jsonify({"error": "Agent orchestration API request failed", "details": err_txt}), 502
    except Exception as e:
        return jsonify({"error": "Server error", "details": str(e)}), 500

@app.route('/workflow/start', methods=['POST'])
def workflow_start():
    """
    Start the workflow from the internal portal using JSON input (no invoice upload).
    Frontend sends either:
      - jsonInput: object/array (preferred)
      - jsonText: stringified JSON
    We forward it to the low-code platform as userInput (string).
    """
    try:
        if not igentic_endpoint:
            return jsonify({"error": "IGENTIC_ENDPOINT is not configured"}), 500

        body = request.get_json(silent=True) or {}
        session_id = body.get("sessionId") or ""
        request_type = body.get("request") or "Start workflow (JSON input)"

        json_input = body.get("jsonInput", None)
        json_text = body.get("jsonText", None)

        if json_input is None and json_text is None:
            return jsonify({"error": "Provide jsonInput (object) or jsonText (string)."}), 400

        # Normalize to a string for the low-code platform
        if json_input is not None:
            user_input = json.dumps(json_input, ensure_ascii=False)
        else:
            user_input = json_text
            # Validate it is JSON to catch obvious UI mistakes early
            try:
                json.loads(json_text)
            except Exception:
                return jsonify({"error": "jsonText must be valid JSON."}), 400

        headers = {"Content-Type": "application/json"}
        payload = {
            "request": request_type,
            "userInput": user_input,
            "sessionId": session_id
        }

        resp = requests.post(igentic_endpoint, json=payload, headers=headers, timeout=30)
        resp.raise_for_status()
        orchestration_response = resp.json()
        workflow = _extract_workflow_output(orchestration_response)

        local_json_backup({
            "timestamp": datetime.now().isoformat(),
            "type": "workflow_start",
            "request": request_type,
            "sessionId": session_id,
            "userInput": user_input,
            "agent_orchestration": orchestration_response,
            "workflow": workflow
        })

        # Update FC Figures store (structured dashboard)
        _upsert_fc_row(workflow.get("sessionId") or session_id, orchestration_response, user_input_str=user_input, event_type="workflow_start")

        return jsonify({"workflow": workflow, "data": orchestration_response}), 200

    except requests.exceptions.RequestException as e:
        err_txt = str(e)
        if hasattr(e, "response") and e.response is not None:
            err_txt = f"{err_txt} | status={e.response.status_code} | body={e.response.text}"
        return jsonify({"error": "Agent orchestration API request failed", "details": err_txt}), 502
    except Exception as e:
        return jsonify({"error": "Server error", "details": str(e)}), 500

@app.route('/workflow/next-participant', methods=['POST'])
def workflow_next_participant():
    """
    Router hook endpoint:
    Frontend sends conversation history + previous agent output, and we forward it
    to the low-code platform which decides the next participant.

    IMPORTANT: We do NOT implement routing logic in code. We only pass inputs through
    and return the platform's output (often a plain-text participant name).
    """
    try:
        if not igentic_endpoint:
            return jsonify({"error": "IGENTIC_ENDPOINT is not configured"}), 500

        body = request.get_json(silent=True) or {}
        history = body.get("history")  # string or array
        previous_output = body.get("previous_output")  # string or object
        session_id = body.get("sessionId") or ""

        if history is None:
            return jsonify({"error": "Missing required field: history"}), 400

        router_input = {
            "history": history,
            "previous_output": previous_output
        }

        headers = {"Content-Type": "application/json"}
        payload = {
            "request": body.get("request") or "Select next participant",
            "userInput": json.dumps(router_input, ensure_ascii=False),
            "sessionId": session_id
        }

        resp = requests.post(igentic_endpoint, json=payload, headers=headers, timeout=30)
        resp.raise_for_status()

        # Could be JSON or plain text; try JSON first, then fall back
        orchestration_response = None
        try:
            orchestration_response = resp.json()
        except Exception:
            orchestration_response = resp.text

        workflow = _extract_workflow_output(orchestration_response)

        local_json_backup({
            "timestamp": datetime.now().isoformat(),
            "type": "workflow_next_participant",
            "sessionId": session_id,
            "router_input": router_input,
            "agent_orchestration": orchestration_response,
            "workflow": workflow
        })

        # Update FC Figures store (structured dashboard)
        _upsert_fc_row(workflow.get("sessionId") or session_id, orchestration_response, user_input_str=json.dumps(router_input, ensure_ascii=False), event_type="workflow_next_participant")

        return jsonify({"workflow": workflow, "data": orchestration_response}), 200

    except requests.exceptions.RequestException as e:
        err_txt = str(e)
        if hasattr(e, "response") and e.response is not None:
            err_txt = f"{err_txt} | status={e.response.status_code} | body={e.response.text}"
        return jsonify({"error": "Agent orchestration API request failed", "details": err_txt}), 502
    except Exception as e:
        return jsonify({"error": "Server error", "details": str(e)}), 500

@app.route('/api/dashboard/delete', methods=['POST'])
def api_dashboard_delete():
    """
    Delete invoices by UUID(s).
    Body: { "ids": ["uuid1", "uuid2", ...] } or { "ids": "uuid1,uuid2" }
    """
    try:
        body = request.get_json(silent=True) or {}
        ids_input = body.get("ids", [])
        
        # Handle both array and comma-separated string
        if isinstance(ids_input, str):
            ids = [i.strip() for i in ids_input.split(",") if i.strip()]
        elif isinstance(ids_input, list):
            ids = [str(i).strip() for i in ids_input if i]
        else:
            return jsonify({"error": "ids must be an array or comma-separated string"}), 400
        
        if not ids:
            return jsonify({"error": "No invoice IDs provided"}), 400
        
        store = _read_fc_store()
        rows = store.get("rows", [])
        
        original_count = len(rows)
        rows = [r for r in rows if not (isinstance(r, dict) and r.get("invoice_uuid") in ids)]
        deleted_count = original_count - len(rows)
        
        store["rows"] = rows
        _write_fc_store(store)
        
        return jsonify({
            "status": "ok",
            "deleted_count": deleted_count,
            "remaining_count": len(rows)
        }), 200
        
    except Exception as e:
        return jsonify({"error": "Server error", "details": str(e)}), 500

@app.route('/api/dashboard/daily-summary', methods=['POST'])
def api_dashboard_daily_summary():
    """
    Generate summaries for all invoices (or selected ones) via orchestrator.
    Body: { "ids": ["uuid1", ...] } or omit for all invoices
    """
    try:
        if not igentic_endpoint:
            return jsonify({"error": "IGENTIC_ENDPOINT is not configured"}), 500
        
        body = request.get_json(silent=True) or {}
        ids_input = body.get("ids", [])
        
        store = _read_fc_store()
        rows = store.get("rows", [])
        
        # Filter rows if IDs provided
        if ids_input:
            if isinstance(ids_input, str):
                ids = [i.strip() for i in ids_input.split(",") if i.strip()]
            else:
                ids = [str(i).strip() for i in ids_input if i]
            rows = [r for r in rows if isinstance(r, dict) and r.get("invoice_uuid") in ids]
        
        if not rows:
            return jsonify({"error": "No invoices found"}), 404
        
        summaries_generated = 0
        errors = []
        
        for row in rows:
            if not row.get("sessionId"):
                errors.append(f"Invoice {row.get('invoice_uuid')} has no sessionId")
                continue
            
            try:
                headers = {"Content-Type": "application/json"}
                payload = {
                    "request": "Summary_Status_Agent (daily summary)",
                    "userInput": json.dumps(
                        {
                            "invoice_number": row.get("invoice_number"),
                            "resource_name": row.get("resource_name"),
                            "vendor_hours": row.get("vendor_hours"),
                            "approved_hours": row.get("approved_hours"),
                            "approval_status": row.get("approval_status"),
                        },
                        ensure_ascii=False,
                    ),
                    "sessionId": row.get("sessionId"),
                }
                resp = requests.post(igentic_endpoint, json=payload, headers=headers, timeout=30)
                resp.raise_for_status()
                orchestration_response = resp.json()
                workflow = _extract_workflow_output(orchestration_response)
                summary_text = workflow.get("display_text") or ""
                
                row["orchestrator_summary"] = summary_text
                row["last_updated_at"] = _now_iso()
                summaries_generated += 1
                
            except Exception as e:
                errors.append(f"Invoice {row.get('invoice_uuid')}: {str(e)}")
        
        _write_fc_store(store)
        
        return jsonify({
            "status": "ok",
            "summaries_generated": summaries_generated,
            "total_processed": len(rows),
            "errors": errors if errors else None
        }), 200
        
    except Exception as e:
        return jsonify({"error": "Server error", "details": str(e)}), 500

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'upload_folder': upload_folder,
        'output_files': output_files
    }), 200

if __name__ == '__main__':
    print("Starting Server...")
    print(f"Upload folder: {upload_folder}")
    print(f"Output file: {output_files}")
    print(f"Frontend folder: {frontend_dir}")
    print("\nServer running on http://localhost:5000")
    app.run(debug=True, host='0.0.0.0', port=5000)
