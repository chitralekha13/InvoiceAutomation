# Invoice Processing System - Technical Documentation

**Version:** 1.0  
**Last Updated:** January 30, 2026  
**Author:** Development Team

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [System Architecture](#system-architecture)
3. [Technology Stack](#technology-stack)
4. [External Dependencies & APIs](#external-dependencies--apis)
5. [Module Breakdown](#module-breakdown)
6. [Core Functions & Data Flow](#core-functions--data-flow)
7. [API Endpoints](#api-endpoints)
8. [Data Storage & File Operations](#data-storage--file-operations)
9. [Frontend Components](#frontend-components)
10. [Error Handling & Security](#error-handling--security)
11. [Deployment & Configuration](#deployment--configuration)
12. [FAQ for Management](#faq-for-management)

---

## Executive Summary

This system is an **invoice processing automation platform** that combines Azure Document Intelligence (OCR) with an AI agent orchestration platform (iGentic) to extract, validate, and manage invoice data. The system processes PDF/image invoices, extracts structured data through AI agents, and provides a web-based dashboard for review and approval workflows.

**Key Capabilities:**
- Automated invoice OCR extraction using Azure Document Intelligence
- AI-powered field extraction via iGentic orchestrator agents
- Web-based dashboard for invoice management
- Workflow automation for approval processes
- Export capabilities for downstream systems

**Architecture Pattern:** REST API backend (Flask) + Static frontend (HTML/CSS/JavaScript) + External AI orchestration

---

## System Architecture

### High-Level Flow

```
┌─────────────┐
│   User      │
│  Uploads    │
│  Invoice    │
└──────┬──────┘
       │
       ▼
┌─────────────────────────────────────┐
│     Frontend (index.html)           │
│  - File upload UI                   │
│  - Dashboard (dashboard.html)       │
└──────┬──────────────────────────────┘
       │ HTTP POST /upload
       ▼
┌─────────────────────────────────────┐
│   Flask Backend (app.py)            │
│   1. Save uploaded file             │
│   2. Call Azure Document Intelligence│
│   3. Extract raw OCR text           │
└──────┬──────────────────────────────┘
       │
       ├─────────────────┐
       ▼                 ▼
┌──────────────┐  ┌──────────────────┐
│   Azure      │  │   iGentic        │
│  Document    │  │   Orchestrator   │
│ Intelligence │  │   (AI Agents)    │
└──────────────┘  └────────┬─────────┘
                           │
                           │ Structured JSON
                           ▼
┌─────────────────────────────────────┐
│   Backend Processing                │
│   - Parse orchestrator response      │
│   - Extract fields (JSON/CSV/MD)     │
│   - Save to fc_figures_store.json    │
│   - Log to output.json              │
└──────┬──────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────┐
│   Dashboard Display                 │
│   - Show extracted invoice data      │
│   - Approval workflow                │
│   - Export functionality             │
└─────────────────────────────────────┘
```

### Component Responsibilities

| Component | Responsibility |
|-----------|---------------|
| **Frontend** | User interface, file upload, dashboard visualization, API calls |
| **Flask Backend** | Request handling, file management, API orchestration, data parsing |
| **Azure Document Intelligence** | OCR extraction from PDF/images |
| **iGentic Orchestrator** | AI agent workflow execution, structured data extraction |
| **JSON Storage** | Persistent data storage (`fc_figures_store.json`, `output.json`) |

---

## Technology Stack

### Backend

| Technology | Version | Purpose |
|------------|---------|---------|
| **Python** | 3.13+ | Core programming language |
| **Flask** | 3.0.0 | Web framework for REST API |
| **flask-cors** | 4.0.0 | Cross-origin resource sharing |
| **requests** | 2.31.0 | HTTP client for external APIs |
| **python-dotenv** | ≥1.0.0 | Environment variable management |
| **python-dateutil** | ≥2.8.0 | Date parsing and normalization |
| **Werkzeug** | 3.0.1 | WSGI utilities (file handling) |

### Frontend

| Technology | Purpose |
|------------|---------|
| **HTML5** | Structure |
| **CSS3** | Styling (modern design system) |
| **JavaScript (Vanilla)** | Client-side logic, API calls |
| **Google Fonts (Inter)** | Typography |

### External Services

| Service | Purpose |
|---------|---------|
| **Azure Document Intelligence** | OCR and invoice field extraction |
| **iGentic Platform** | AI agent orchestration and workflow management |

---

## External Dependencies & APIs

### 1. Azure Document Intelligence (Form Recognizer)

**Purpose:** Extract text and structured fields from invoice PDFs/images

**API Details:**
- **Endpoint:** Configured via `AZURE_DI_ENDPOINT` environment variable
- **Authentication:** API key via `AZURE_DI_KEY`
- **API Version:** Supports multiple versions (2023-07-31, 2024-11-30)
- **Model Used:** `prebuilt-invoice`
- **API Paths Tried:**
  - `/formrecognizer/documentModels/prebuilt-invoice:analyze`
  - `/documentintelligence/documentModels/prebuilt-invoice:analyze`

**Implementation:**
- Uses REST API (not SDK) for Python 3.13 compatibility
- Asynchronous pattern: POST analyze → poll GET until `status: "succeeded"`
- Extracts: invoice number, vendor name, dates, amounts, line items

**Function:** `_analyze_invoice_rest(file_path)` (lines 53-111)

**When Called:** During `/upload` route → `invoice_proc_az()` → `_analyze_invoice_rest()`

**Data Returned:**
```json
{
  "extracted_text": ["line1", "line2", ...],
  "full_text": "complete document text",
  "structured_extraction": {
    "invoice_number": "...",
    "invoice_amount": 1234.56,
    ...
  }
}
```

---

### 2. iGentic Orchestrator Platform

**Purpose:** AI agent workflow execution for structured invoice data extraction

**API Details:**
- **Endpoint:** Configured via `IGENTIC_ENDPOINT` environment variable
- **Default:** `https://bluecoast-sk-eqe8f4e7e8gyfyds.eastus2-01.azurewebsites.net/api/iGenticAutonomousAgent/Executor/45d4a92e-168e-448a-97ee-567da3e0174e`
- **Authentication:** Not required (public endpoint)
- **Request Format:** JSON POST
- **Timeout:** 30 seconds

**Agents in Workflow:**
1. **Invoice_Parser_Agent** - Extracts invoice fields from OCR text
2. **Excel_Formatter_Agent** - Formats data for Excel export
3. **Timesheet_Verification_Agent** - Validates hours, sets approval status
4. **Summary_Status_Agent** - Provides status summary
5. **Payment_Approval_Agent** - Marks invoice ready for payment

**Function:** `igentic_json_post(invoice_data)` (lines 826-877)

**When Called:**
- `/upload` route: Sends raw OCR text for initial extraction
- `/workflow/continue` route: Sends user input (e.g., approved hours)
- `/workflow/next-participant` route: Advances workflow to next agent
- `/api/fcfigures/<uuid>/update` route: Updates invoice with approved hours

**Request Payload:**
```json
{
  "request": "Process invoice",
  "userInput": "{\"full_text\": \"...\", \"extracted_text\": [...]}",
  "sessionId": "uuid-string"
}
```

**Response Format:**
```json
{
  "result": "markdown text with extracted fields",
  "agentResponses": "[{\"AuthorName\": \"...\", \"Content\": \"...\"}]",
  "sessionId": "uuid-string",
  "nextParticipant": "agent-name"
}
```

**Data Extraction:** The backend parses orchestrator responses in multiple formats:
- JSON blocks: ` ```json { ... } ``` `
- CSV blocks: ` ```csv ... ``` `
- Markdown summary: `- **Field Name:** Value`

---

## Module Breakdown

### Backend Module: `app.py`

**Total Lines:** ~2,576  
**Purpose:** Main Flask application with all business logic

#### Imports & Dependencies

```python
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
from werkzeug.utils import secure_filename
import json
from datetime import datetime, timedelta
import requests
import re
import uuid
import csv
import time
from dotenv import load_dotenv
```

#### Configuration Variables

| Variable | Source | Purpose |
|----------|--------|---------|
| `az_di_endpoint` | `AZURE_DI_ENDPOINT` env var | Azure Document Intelligence endpoint |
| `az_di_key` | `AZURE_DI_KEY` env var | Azure API key |
| `igentic_endpoint` | `IGENTIC_ENDPOINT` env var | iGentic orchestrator URL |
| `upload_folder` | `Backend/invoice uploads/` | Directory for uploaded files |
| `output_files` | `Backend/output.json` | Audit log file |
| `fc_figures_store_file` | `Backend/fc_figures_store.json` | Dashboard data storage |

---

## Core Functions & Data Flow

### 1. File Upload & OCR Processing

**Route:** `POST /upload` (lines 2142-2251)

**Flow:**
1. **File Validation** → `allowed_file(filename)` checks extension (PDF, PNG, JPG, JPEG)
2. **File Saving** → `secure_filename()` sanitizes name, adds timestamp prefix
3. **OCR Extraction** → `invoice_proc_az(file_path)` calls Azure Document Intelligence
4. **Orchestrator Call** → `igentic_json_post()` sends raw OCR text to iGentic
5. **Data Extraction** → `_extract_structured_from_orchestrator()` parses response
6. **Storage** → `_upsert_fc_row()` saves to `fc_figures_store.json`
7. **Audit Log** → `local_json_backup()` appends to `output.json`

**Key Functions:**

| Function | Lines | Purpose |
|----------|-------|---------|
| `allowed_file()` | 50-51 | Validates file extension |
| `invoice_proc_az()` | 272-297 | Orchestrates OCR (Azure DI or PDF fallback) |
| `_analyze_invoice_rest()` | 53-111 | Calls Azure Document Intelligence REST API |
| `_invoice_data_from_rest_result()` | 114-164 | Converts Azure response to internal format |
| `igentic_json_post()` | 826-877 | Sends data to iGentic orchestrator |

---

### 2. OCR Processing Functions

#### `_analyze_invoice_rest(file_path)`

**Purpose:** Call Azure Document Intelligence REST API

**Process:**
1. Reads file as binary
2. Tries multiple API paths (`formrecognizer` vs `documentintelligence`)
3. POSTs to `/documentModels/prebuilt-invoice:analyze`
4. Polls `Operation-Location` header until `status: "succeeded"`
5. Returns invoice data dict

**External Calls:**
- `POST {endpoint}/formrecognizer/documentModels/prebuilt-invoice:analyze`
- `GET {operation_location}` (polling)

**Returns:** `invoice_data` dict with `extracted_text`, `full_text`, `structured_extraction`

---

#### `_invoice_data_from_rest_result(file_path, result)`

**Purpose:** Convert Azure API response to internal format

**Process:**
1. Extracts text from `pages[].lines[].content`
2. Builds `extracted_text` array and `full_text` string
3. Extracts structured fields from `documents[0].fields`
4. Maps Azure field names to canonical names:
   - `InvoiceId` → `invoice_number`
   - `VendorName` → `consultancy_name`
   - `InvoiceTotal` → `invoice_amount`
   - `InvoiceDate` → `invoice_date`
   - `DueDate` → `due_date`

**Function Called:** `_parsed_from_rest_invoice_fields()` (lines 187-237)

---

### 3. Orchestrator Integration Functions

#### `igentic_json_post(invoice_data)`

**Purpose:** Send invoice data to iGentic orchestrator

**Process:**
1. Builds payload: `{"request": "Process invoice", "userInput": json.dumps(data), "sessionId": ""}`
2. POSTs to `igentic_endpoint` with JSON headers
3. Returns response JSON or error dict

**External Calls:**
- `POST {igentic_endpoint}` with JSON payload

**Returns:** Orchestrator response dict

**Error Handling:** Catches `requests.exceptions.RequestException`, returns error dict

---

#### `_extract_workflow_output(orchestration_response)`

**Purpose:** Extract workflow metadata from orchestrator response

**Process:**
1. Extracts `sessionId` from response
2. Extracts `nextParticipant` (next agent name)
3. Extracts `display_text` (agent output):
   - From `result` field (if string)
   - From `agentResponses` JSON array (last agent's `Content`)
4. Normalizes participant name via `_maybe_participant_name()`

**Returns:**
```python
{
  "raw": orchestration_response,
  "next_participant": "agent-name",
  "display_text": "markdown text",
  "sessionId": "uuid"
}
```

**Function Called:** `_maybe_participant_name()` (lines 1665-1673)

---

### 4. Data Extraction Functions

#### `_extract_structured_from_orchestrator(orchestration_response, display_text, user_input_str=None)`

**Purpose:** Parse structured invoice fields from orchestrator response

**Priority Order (tries each until data found):**

1. **Priority 1:** Direct JSON in `orchestration_response` (if dict with invoice fields)
2. **Priority 2:** JSON block extraction from `display_text`:
   - Pattern: ` ```json { ... } ``` `
   - Function: `_extract_json_block()` (lines 927-967)
3. **Priority 3:** CSV block extraction from `display_text`:
   - Pattern: ` ```csv ... ``` ` or plain CSV lines
   - Function: `_extract_csv_block()` (lines 968-1115)
4. **Priority 3b:** Markdown summary extraction:
   - Pattern: `- **Field Name:** Value` or `**Field_Name:** Value`
   - Function: `_extract_markdown_summary()` (lines 1116-1215)
5. **Priority 4:** Extract from `agentResponses` JSON string array
6. **Priority 5:** Extract from `user_input_str` if it contains `parsed_data` (deprecated)

**Key Normalization:**
- Converts PascalCase keys (`InvoiceNumber`) → snake_case (`invoice_number`)
- Converts PascalCase with underscores (`Invoice_Number`) → snake_case (`invoice_number`)
- Handles date normalization via `_normalize_date_str()`

**Returns:** Dict with extracted fields or `None`

**Functions Called:**
- `_extract_json_block()` - Extracts JSON from markdown code blocks
- `_extract_csv_block()` - Parses CSV data (handles quoted fields, skips JSON-like lines)
- `_extract_markdown_summary()` - Parses bulleted markdown summaries
- `_has_usable_values()` - Validates extracted data has non-empty values
- `_normalize_date_str()` - Converts dates to YYYY-MM-DD format

---

#### `_extract_json_block(text)`

**Purpose:** Extract JSON object from markdown code block

**Process:**
1. Finds ` ```json` or ` ``` ` blocks
2. Extracts content between backticks
3. Parses JSON with `json.loads()`
4. Returns dict if valid

**Returns:** Dict or `None`

---

#### `_extract_csv_block(text)`

**Purpose:** Extract CSV data from markdown or plain text

**Process:**
1. Finds CSV in ` ```csv` blocks or plain lines
2. Parses CSV with `csv.reader()`
3. Converts first row to headers, subsequent rows to data
4. Skips lines that look like JSON (to avoid misparsing)
5. Normalizes keys to snake_case

**Returns:** Dict with extracted fields or `None`

---

#### `_extract_markdown_summary(text)`

**Purpose:** Extract fields from markdown bullet format

**Process:**
1. Detects headers like "Invoice Summary" or "Extracted Information"
2. Uses regex: `[-•]?\s*\*\*([^*]+)\*\*:\s*(.+?)(?=\n[-•]?\s*\*\*|\n\n|\Z)`
3. Extracts field-value pairs
4. Normalizes keys (PascalCase → snake_case)
5. Converts types (dates, numbers)

**Returns:** Dict with extracted fields or `None`

---

### 5. Data Storage Functions

#### `_upsert_fc_row(session_id, orchestration_response, user_input_str=None, pre_structured=None, event_type=None)`

**Purpose:** Create or update dashboard row from orchestrator response

**Process:**
1. Reads `fc_figures_store.json` via `_read_fc_store()`
2. Extracts workflow output via `_extract_workflow_output()`
3. Extracts structured fields via `_extract_structured_from_orchestrator()`
4. **Row Finding Logic:**
   - If `event_type == "upload"`: Always create new row (allows duplicates)
   - Otherwise: Try to find existing row by `session_id` or `invoice_number`
5. Creates new row if not found:
   ```python
   {
     "invoice_uuid": uuid4(),
     "created_at": ISO timestamp,
     "sessionId": session_id,
     "approval_status": "Pending",  # default for new rows
     ...
   }
   ```
6. Updates row with extracted fields
7. Extracts status via `_extract_status_from_orchestrator()`
8. Saves to `fc_figures_store.json` via `_write_fc_store()`

**Functions Called:**
- `_read_fc_store()` - Reads JSON file
- `_extract_workflow_output()` - Extracts workflow metadata
- `_extract_structured_from_orchestrator()` - Extracts invoice fields
- `_extract_status_from_orchestrator()` - Extracts approval status
- `_find_row_by_session_or_invoice()` - Finds existing row
- `_write_fc_store()` - Writes JSON file

**Returns:** Updated/created row dict

---

#### `local_json_backup(data)`

**Purpose:** Append audit log entry to `output.json`

**Process:**
1. Reads existing `output.json` (or creates empty list)
2. Appends new data entry
3. Writes back to file

**When Called:**
- After `/upload` - logs invoice processing
- After `/workflow/continue` - logs workflow steps
- After `/workflow/next-participant` - logs participant changes
- After `/api/fcfigures/<uuid>/update` - logs manual updates

**File:** `Backend/output.json`

---

### 6. Status Extraction Functions

#### `_extract_status_from_orchestrator(orchestration_response, display_text)`

**Purpose:** Extract approval status from orchestrator response

**Process:**
1. Checks `orchestration_response` dict for status fields:
   - `approval_status`
   - `status`
   - `fc_figures_row.approval_status`
2. Parses `display_text` for status keywords:
   - "Complete", "COMPLETE" → `"Complete"`
   - "Need manual review", "NEED APPROVAL" → `"NEED APPROVAL"`
   - "Pending" → `"Pending"`
3. Returns normalized status string

**Returns:** Status string or `None`

---

### 7. Utility Functions

| Function | Lines | Purpose |
|----------|-------|---------|
| `_normalize_date_str()` | 299-339 | Converts dates to YYYY-MM-DD format |
| `_month_name_to_dates()` | 340-369 | Converts month name + year to date range |
| `_now_iso()` | 887-888 | Returns current timestamp in ISO format |
| `_read_json_file()` | 890-898 | Safe JSON file reading with default |
| `_write_json_file()` | 900-906 | Safe JSON file writing |
| `_read_fc_store()` | 908-912 | Reads dashboard data file |
| `_write_fc_store()` | 914-915 | Writes dashboard data file |
| `_find_row_by_session_or_invoice()` | 917-925 | Finds row by session ID or invoice number |
| `_safe_get()` | 879-885 | Safe nested dict access |

---

## API Endpoints

### Public Routes (Serve Frontend)

| Route | Method | Purpose |
|-------|--------|---------|
| `/` | GET | Serves `index.html` (upload page) |
| `/dashboard` | GET | Serves `dashboard.html` (dashboard page) |
| `/dashboard/recent` | GET | Serves `dashboard.html` with recent filter |

### API Endpoints

#### 1. `POST /upload`

**Purpose:** Upload and process invoice file

**Request:**
- Content-Type: `multipart/form-data`
- Field: `file` (PDF, PNG, JPG, JPEG)

**Process:**
1. Validates file extension
2. Saves file with timestamp prefix
3. Calls Azure Document Intelligence for OCR
4. Sends raw OCR text to iGentic orchestrator
5. Extracts structured data from orchestrator response
6. Creates dashboard row
7. Logs to `output.json`

**Response:**
```json
{
  "message": "File uploaded and processed successfully",
  "filename": "20260130_123456_invoice.pdf",
  "data": {
    "invoice_processing": {...},
    "agent_orchestration": {...},
    "workflow": {...}
  },
  "workflow": {
    "next_participant": "agent-name",
    "display_text": "...",
    "sessionId": "uuid"
  },
  "invoice_uuid": "uuid"
}
```

**External Calls:**
- Azure Document Intelligence REST API
- iGentic orchestrator API

**File Operations:**
- Write: `Backend/invoice uploads/{timestamp}_{filename}`
- Write: `Backend/fc_figures_store.json`
- Append: `Backend/output.json`

---

#### 2. `GET /api/dashboard/data`

**Purpose:** Retrieve dashboard invoice data

**Query Parameters:**
- `status` (optional): Filter by approval status
- `search` (optional): Search in invoice number, vendor name, etc.

**Response:**
```json
{
  "status": "ok",
  "metrics": {
    "total": 10,
    "pending": 5,
    "complete": 3,
    "need_approval": 2,
    "payment_initiated": 1,
    "total_amount": 12345.67
  },
  "rows": [...]
}
```

**File Operations:**
- Read: `Backend/fc_figures_store.json`

---

#### 3. `POST /api/fcfigures/<invoice_uuid>/update`

**Purpose:** Update manual fields (notes, BU, Project, Approved Hours)

**Request Body:**
```json
{
  "current_comments": "...",
  "business_unit": "...",
  "project_name": "...",
  "approved_hours": 144.0,
  ...
}
```

**Process:**
1. Updates row in `fc_figures_store.json`
2. If `approved_hours` provided and `sessionId` exists:
   - Calls iGentic orchestrator with approved hours
   - Updates row from orchestrator response

**External Calls:**
- iGentic orchestrator API (if approved_hours provided)

**File Operations:**
- Read/Write: `Backend/fc_figures_store.json`
- Append: `Backend/output.json`

---

#### 4. `POST /api/fcfigures/<invoice_uuid>/summary`

**Purpose:** Generate summary via orchestrator

**Request Body:**
```json
{
  "sessionId": "uuid"
}
```

**Process:**
1. Calls iGentic orchestrator with summary request
2. Returns orchestrator response

**External Calls:**
- iGentic orchestrator API

**File Operations:**
- Append: `Backend/output.json`

---

#### 5. `POST /workflow/continue`

**Purpose:** Continue workflow with user input

**Request Body:**
```json
{
  "userInput": "approved hours: 144",
  "sessionId": "uuid",
  "request": "Continue workflow"
}
```

**Process:**
1. Forwards request to iGentic orchestrator
2. Updates dashboard row from response
3. Logs to `output.json`

**External Calls:**
- iGentic orchestrator API

**File Operations:**
- Read/Write: `Backend/fc_figures_store.json`
- Append: `Backend/output.json`

---

#### 6. `POST /workflow/next-participant`

**Purpose:** Advance workflow to next agent

**Request Body:**
```json
{
  "sessionId": "uuid"
}
```

**Process:**
1. Calls iGentic orchestrator to advance workflow
2. Updates dashboard row from response
3. Logs to `output.json`

**External Calls:**
- iGentic orchestrator API

**File Operations:**
- Read/Write: `Backend/fc_figures_store.json`
- Append: `Backend/output.json`

---

#### 7. `GET /api/dashboard/export`

**Purpose:** Export dashboard data as CSV

**Query Parameters:**
- `status` (optional): Filter by status

**Response:**
- Content-Type: `text/csv`
- CSV file with invoice data

**File Operations:**
- Read: `Backend/fc_figures_store.json`

---

#### 8. `POST /api/dashboard/delete`

**Purpose:** Delete invoice row

**Request Body:**
```json
{
  "invoice_uuid": "uuid"
}
```

**File Operations:**
- Read/Write: `Backend/fc_figures_store.json`

---

#### 9. `POST /api/dashboard/daily-summary`

**Purpose:** Generate daily summary report

**Request Body:**
```json
{
  "date": "2026-01-30"
}
```

**File Operations:**
- Read: `Backend/fc_figures_store.json`

---

#### 10. `GET /health`

**Purpose:** Health check endpoint

**Response:**
```json
{
  "status": "ok",
  "timestamp": "2026-01-30T12:34:56"
}
```

---

## Data Storage & File Operations

### File Structure

```
Backend/
├── app.py                          # Main Flask application
├── fc_figures_store.json           # Dashboard data (persistent)
├── output.json                     # Audit log (append-only)
└── invoice uploads/                # Uploaded files directory
    └── {timestamp}_{filename}.pdf
```

### `fc_figures_store.json` Structure

**Purpose:** Stores all invoice data for dashboard display

**Format:**
```json
{
  "rows": [
    {
      "invoice_uuid": "uuid",
      "sessionId": "uuid",
      "created_at": "2026-01-30T12:34:56",
      "last_updated_at": "2026-01-30T12:34:56",
      "invoice_number": "INV-001",
      "invoice_date": "2026-01-15",
      "due_date": "2026-02-15",
      "consultancy_name": "Vendor Inc",
      "resource_name": "John Doe",
      "vendor_hours": 144.0,
      "pay_rate": 100.0,
      "invoice_amount": 14400.0,
      "approval_status": "Pending",
      "approved_hours": null,
      "business_unit": null,
      "project_name": null,
      "current_comments": "",
      "bill_pay_initiated_on": null,
      "doc_name": "20260130_123456_invoice.pdf",
      "last_agent_text": "markdown output",
      "last_agent_name": "Invoice_Parser_Agent",
      "last_event_type": "upload"
    }
  ]
}
```

**Read Operations:**
- `_read_fc_store()` - Reads entire file
- `api_dashboard_data()` - Reads and filters rows
- `api_fcfigures_update()` - Reads, updates row, writes back

**Write Operations:**
- `_write_fc_store()` - Writes entire file
- `_upsert_fc_row()` - Reads, modifies rows array, writes back

**Concurrency:** File-based (no locking) - suitable for single-instance deployment

---

### `output.json` Structure

**Purpose:** Audit log of all processing activities

**Format:**
```json
[
  {
    "timestamp": "2026-01-30T12:34:56",
    "type": "upload",
    "uploaded_file": "20260130_123456_invoice.pdf",
    "invoice_processing": {...},
    "agent_orchestration": {...},
    "workflow": {...}
  },
  {
    "timestamp": "2026-01-30T12:35:00",
    "type": "workflow_continue",
    "sessionId": "uuid",
    "userInput": "144",
    "agent_orchestration": {...}
  }
]
```

**Append Operations:**
- `local_json_backup()` - Appends new entry

**Read Operations:**
- `_read_output_log()` - Reads entire log (for debugging)

---

### Uploaded Files Storage

**Directory:** `Backend/invoice uploads/`

**Naming Convention:** `{YYYYMMDD}_{HHMMSS}_{original_filename}`

**Example:** `20260130_123456_Invoice_1_completed.pdf`

**Operations:**
- Write: `file.save(file_path)` in `/upload` route
- Read: Not directly accessed by application (stored for audit)

**Cleanup:** Not automated - manual cleanup recommended

---

## Frontend Components

### 1. Upload Page (`index.html`)

**Purpose:** File upload interface

**Key Features:**
- Drag-and-drop file upload
- File validation (client-side)
- Progress indication
- Success/error messaging
- Navigation to dashboard

**JavaScript Functions:**
- `handleFileSelect()` - Handles file input change
- `uploadFile()` - POSTs file to `/upload`
- `routeNextParticipant()` - Conditionally calls `/workflow/next-participant`

**API Calls:**
- `POST /upload` - Uploads file

---

### 2. Dashboard Page (`dashboard.html`)

**Purpose:** Invoice management dashboard

**Key Features:**
- Invoice table with sorting/filtering
- Status metrics (pending, complete, etc.)
- Search functionality
- Export to CSV
- Row details panel
- Manual field editing
- Workflow actions (approve, continue)

**JavaScript Functions:**
- `loadDashboard()` - Fetches data from `/api/dashboard/data`
- `updateRow()` - POSTs updates to `/api/fcfigures/<uuid>/update`
- `deleteRow()` - POSTs delete to `/api/dashboard/delete`
- `exportCSV()` - GETs `/api/dashboard/export`
- `showDetails()` - Displays row details panel
- `continueWorkflow()` - POSTs to `/workflow/continue` or `/workflow/next-participant`

**API Calls:**
- `GET /api/dashboard/data` - Fetches invoice data
- `POST /api/fcfigures/<uuid>/update` - Updates row
- `POST /api/fcfigures/<uuid>/summary` - Generates summary
- `POST /workflow/continue` - Continues workflow
- `POST /workflow/next-participant` - Advances workflow
- `GET /api/dashboard/export` - Exports CSV

---

## Error Handling & Security

### Error Handling

**Backend Error Handling:**
- Try-except blocks around external API calls
- JSON parsing errors caught and logged
- File I/O errors handled gracefully
- HTTP errors from APIs logged with status codes

**Error Responses:**
- `400 Bad Request` - Invalid input (missing file, invalid type)
- `500 Internal Server Error` - Server errors (API failures, parsing errors)

**Logging:**
- `print()` statements for debugging (can be replaced with proper logging)

---

### Security Considerations

**File Upload Security:**
- `secure_filename()` sanitizes filenames
- Extension validation via `allowed_file()`
- Files saved with timestamp prefix (prevents overwrites)

**API Security:**
- CORS enabled (allows frontend to call backend)
- No authentication implemented (add if needed)
- Environment variables for sensitive data (API keys)

**Data Validation:**
- Date normalization prevents invalid dates
- Type conversion with error handling
- Field extraction validates non-empty values

**Recommendations:**
- Add authentication/authorization
- Implement rate limiting
- Add input sanitization for user-provided text
- Encrypt sensitive data at rest
- Add HTTPS in production

---

## Deployment & Configuration

### Environment Variables

**Required:**
- `AZURE_DI_ENDPOINT` - Azure Document Intelligence endpoint URL
- `AZURE_DI_KEY` - Azure Document Intelligence API key

**Optional:**
- `IGENTIC_ENDPOINT` - iGentic orchestrator endpoint (default provided)

**File:** `.env` (not committed to git)

**Example:**
```env
AZURE_DI_ENDPOINT=https://your-resource.cognitiveservices.azure.com/
AZURE_DI_KEY=your-api-key-here
IGENTIC_ENDPOINT=https://your-igentic-endpoint/api/...
```

---

### Installation

**1. Install Python Dependencies:**
```bash
pip install -r requirements.txt
```

**2. Configure Environment:**
```bash
cp .env.example .env
# Edit .env with your Azure and iGentic credentials
```

**3. Run Application:**
```bash
cd Backend
python app.py
```

**Default Port:** 5000 (configurable in `app.py`)

---

### Production Deployment

**Considerations:**
- Use production WSGI server (Gunicorn, uWSGI)
- Configure reverse proxy (Nginx, Apache)
- Enable HTTPS (SSL/TLS certificates)
- Set up logging (replace `print()` with proper logger)
- Implement database (replace JSON files with PostgreSQL/MySQL)
- Add monitoring and alerting
- Set up backup for `fc_figures_store.json`

**Example Gunicorn:**
```bash
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

---

## FAQ for Management

### Q1: What does this system do?

**A:** This system automates invoice processing by:
1. Extracting text from invoice PDFs/images using Azure Document Intelligence (OCR)
2. Using AI agents (via iGentic platform) to extract structured fields (invoice number, amounts, dates, etc.)
3. Providing a web dashboard for review, approval, and workflow management
4. Enabling export of processed data for downstream systems

---

### Q2: What external services do we depend on?

**A:** Two external services:
1. **Azure Document Intelligence** - Microsoft's OCR service for invoice extraction
2. **iGentic Platform** - AI agent orchestration platform that runs workflow agents

**Cost Implications:**
- Azure Document Intelligence: Pay-per-use pricing (per page/document)
- iGentic: Platform-specific pricing (check with provider)

---

### Q3: Where is the data stored?

**A:** Data is stored in JSON files on the server:
- **`fc_figures_store.json`** - All invoice data for dashboard (persistent)
- **`output.json`** - Audit log of all processing activities
- **`invoice uploads/`** - Original uploaded PDF/image files

**Note:** This is file-based storage suitable for single-instance deployment. For production scale, consider migrating to a database (PostgreSQL, MySQL).

---

### Q4: How does the AI extraction work?

**A:** The system uses a two-stage approach:
1. **Azure Document Intelligence** extracts raw text and some structured fields from invoices
2. **iGentic Orchestrator** runs AI agents that:
   - Parse the OCR text
   - Extract invoice fields (number, dates, amounts, vendor, etc.)
   - Validate data (e.g., hours, rates)
   - Determine approval status
   - Format data for export

The backend parses the orchestrator's response (which can be JSON, CSV, or markdown) and populates the dashboard.

---

### Q5: What happens if Azure or iGentic is down?

**A:** 
- **Azure Down:** File uploads will fail with an error message. The system requires Azure for OCR.
- **iGentic Down:** File uploads will fail when trying to extract structured data. The system requires iGentic for field extraction.

**Mitigation:** Implement retry logic, caching, or fallback mechanisms if needed.

---

### Q6: Can we process invoices without iGentic?

**A:** Currently, no. The system relies entirely on iGentic for structured field extraction. Local parsing logic was removed to avoid duplication. If iGentic is unavailable, uploads will fail.

**Alternative:** Re-implement local parsing logic as a fallback (previously existed but was removed).

---

### Q7: How do we handle duplicate invoices?

**A:** The system allows duplicate uploads. Each upload creates a new entry in the dashboard, even if the invoice number is the same. This enables comparison of multiple uploads of the same invoice.

**To prevent duplicates:** Modify `_upsert_fc_row()` to check for existing invoice numbers before creating new rows.

---

### Q8: What is the workflow automation?

**A:** The iGentic orchestrator runs multiple agents in sequence:
1. **Invoice_Parser_Agent** - Extracts fields
2. **Excel_Formatter_Agent** - Formats for export
3. **Timesheet_Verification_Agent** - Validates hours, sets status
4. **Summary_Status_Agent** - Provides summary
5. **Payment_Approval_Agent** - Marks ready for payment

Users can advance the workflow manually via the dashboard or it can run automatically.

---

### Q9: How do we scale this system?

**A:** Current limitations:
- File-based storage (not suitable for high concurrency)
- Single-instance Flask server
- No authentication/authorization
- No database (JSON files)

**Scaling Steps:**
1. Migrate to database (PostgreSQL/MySQL)
2. Use production WSGI server (Gunicorn) with multiple workers
3. Add load balancer for multiple instances
4. Implement caching (Redis) for frequently accessed data
5. Add authentication/authorization
6. Set up monitoring and alerting

---

### Q10: What are the maintenance requirements?

**A:**
- **Azure Document Intelligence:** Monitor usage and costs
- **iGentic Platform:** Ensure endpoint remains accessible, monitor agent performance
- **File Storage:** Clean up old uploaded files periodically
- **JSON Files:** Backup `fc_figures_store.json` regularly
- **Dependencies:** Keep Python packages updated for security patches

---

### Q11: How do we add new invoice fields?

**A:** 
1. Update iGentic agent instructions to extract the new field
2. The backend will automatically parse it from the orchestrator response (no code changes needed if field name follows conventions)
3. Update dashboard HTML to display the new field
4. Update export CSV function if needed

---

### Q12: What is the performance like?

**A:**
- **OCR Processing:** ~5-10 seconds per invoice (Azure API polling)
- **AI Extraction:** ~2-5 seconds (iGentic API call)
- **Total Upload Time:** ~7-15 seconds per invoice
- **Dashboard Load:** <1 second (reads JSON file)

**Bottlenecks:**
- External API calls (Azure, iGentic)
- File I/O (JSON reads/writes)

---

### Q13: How do we debug issues?

**A:**
1. Check `output.json` for audit log of all processing
2. Check server console logs (print statements)
3. Review `fc_figures_store.json` for data state
4. Test Azure/iGentic endpoints directly
5. Check browser console for frontend errors

**Debug Endpoints:**
- `GET /health` - Health check
- `GET /api/dashboard/data` - View current data

---

### Q14: What data formats does the system support?

**A:**
- **Input:** PDF, PNG, JPG, JPEG files
- **Output:** JSON (dashboard), CSV (export)
- **Orchestrator Responses:** JSON blocks, CSV blocks, Markdown summaries

---

### Q15: Is the code production-ready?

**A:** The code is functional but has areas for improvement:
- ✅ Core functionality works
- ✅ Error handling implemented
- ⚠️ Uses `print()` instead of proper logging
- ⚠️ File-based storage (not scalable)
- ⚠️ No authentication/authorization
- ⚠️ No automated tests
- ⚠️ Single-instance deployment only

**Recommendation:** Address the ⚠️ items before production deployment.

---

## Conclusion

This documentation provides a comprehensive overview of the invoice processing system's architecture, functions, and operations. For technical questions or clarifications, refer to the specific sections above or review the source code in `Backend/app.py`.

**Key Takeaways:**
- System uses Azure Document Intelligence for OCR and iGentic for AI extraction
- Data stored in JSON files (consider database migration for scale)
- All field extraction handled by iGentic agents (no local parsing)
- Web-based dashboard for management and approval workflows
- File-based storage suitable for single-instance deployment

---

**Document Version:** 1.0  
**Last Updated:** January 30, 2026
